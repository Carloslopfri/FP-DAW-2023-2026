-- phpMyAdmin SQL Dump
-- version 5.1.1deb5ubuntu1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Xerado en: 06 de Feb de 2025 ás 19:39
-- Versión do servidor: 8.0.40-0ubuntu0.22.04.1
-- Versión do PHP: 8.1.2-1ubuntu2.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `proxectopaisaxes`
--

-- --------------------------------------------------------

--
-- Estrutura da táboa `proxecto05_comentarios`
--

CREATE TABLE `proxecto05_comentarios` (
  `id` int NOT NULL,
  `contido` text COLLATE utf8mb4_spanish_ci NOT NULL,
  `data` date NOT NULL,
  `puntuacion` int NOT NULL,
  `likes` int NOT NULL,
  `paisaxe_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- A extraer os datos da táboa `proxecto05_comentarios`
--

INSERT INTO `proxecto05_comentarios` (`id`, `contido`, `data`, `puntuacion`, `likes`, `paisaxe_id`) VALUES
(1, 'Encantoume a paisaxe, é moi bonita.', '2024-12-01', 5, 3, 1),
(2, 'Viva el Camino de Santiago!!!!!', '2022-12-06', 5, 15, 16),
(3, 'La mejor experiencia, la recomiendo muchiiisimo.', '2023-12-02', 5, 7, 14),
(4, 'Viva Ferrol!!!!', '2018-10-09', 5, 10, 1),
(9, 'O Barrio da Magdalena é precioso.', '2024-12-10', 0, 0, 2),
(10, 'Increible!!!', '2024-12-10', 0, 0, 2),
(12, 'A lugar é moi fermosa.', '2024-12-10', 0, 0, 4);

-- --------------------------------------------------------

--
-- Estrutura da táboa `proxecto05_concellos`
--

CREATE TABLE `proxecto05_concellos` (
  `id` int NOT NULL,
  `nome` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL,
  `provincia` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL,
  `imaxe` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL,
  `poboacion` int NOT NULL,
  `superficie` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- A extraer os datos da táboa `proxecto05_concellos`
--

INSERT INTO `proxecto05_concellos` (`id`, `nome`, `provincia`, `imaxe`, `poboacion`, `superficie`) VALUES
(1, 'Ferrol', 'A Coruña', 'ferrol.jpg', 63890, 82.65),
(2, 'Narón', 'A Coruña', 'naron.jpg', 39051, 66.91),
(3, 'Neda', 'A Coruña', 'neda.jpg', 6687, 23.89),
(4, 'Fene', 'A Coruña', 'fene.jpg', 12850, 23.9),
(5, 'Cabanas', 'A Coruña', 'cabanas.jpg', 3300, 30.32),
(6, 'Pontedeume', 'A Coruña', 'pontedeume.jpg', 7520, 29.26),
(7, 'Miño', 'A Coruña', 'mino.jpg', 6753, 32.97),
(8, 'Paderne', 'A Coruña', 'pederne.jpg', 2436, 38.3),
(9, 'Betanzos', 'A Coruña', 'betanzos.jpg', 13082, 24.19),
(10, 'Abegondo', 'A Coruña', 'abegondo.jpg', 5584, 83.81),
(11, 'Mesia', 'A Coruña', 'mesia.jpg', 2478, 107.07),
(12, 'Ordes', 'A Coruña', 'ordes.jpg', 14174, 157.23),
(13, 'Oroso', 'A Coruña', 'oroso.jpg', 7622, 72.6),
(14, 'Santiago', 'A Coruña', 'santiago.jpg', 97849, 220.01);

-- --------------------------------------------------------

--
-- Estrutura da táboa `proxecto05_concello_ruta`
--

CREATE TABLE `proxecto05_concello_ruta` (
  `concello_id` int NOT NULL,
  `ruta_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- A extraer os datos da táboa `proxecto05_concello_ruta`
--

INSERT INTO `proxecto05_concello_ruta` (`concello_id`, `ruta_id`) VALUES
(1, 2),
(2, 2),
(3, 2),
(4, 3),
(5, 3),
(6, 3),
(7, 4),
(8, 4),
(9, 4),
(10, 5),
(11, 5),
(12, 6),
(13, 6),
(14, 7);

-- --------------------------------------------------------

--
-- Estrutura da táboa `proxecto05_paisaxes`
--

CREATE TABLE `proxecto05_paisaxes` (
  `id` int NOT NULL,
  `nome` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL,
  `altitud` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL,
  `clima` enum('humedo','seco') COLLATE utf8mb4_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_spanish_ci NOT NULL,
  `imaxe` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL,
  `ubicacion` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL,
  `ruta_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- A extraer os datos da táboa `proxecto05_paisaxes`
--

INSERT INTO `proxecto05_paisaxes` (`id`, `nome`, `altitud`, `clima`, `descripcion`, `imaxe`, `ubicacion`, `ruta_id`) VALUES
(1, 'Porto de Ferrol', '0', 'humedo', 'O Porto de Ferrol, situado na costa norte de Galicia, é un dos puntos históricos de partida do Camiño Inglés. Este porto foi, dende a Idade Media, un lugar clave para os peregrinos do norte de Europa, especialmente de Inglaterra, Irlanda e Escandinavia, que chegaban por mar para iniciar a súa peregrinación a Santiago de Compostela. O Porto de Ferrol mantén hoxe a súa relevancia como punto de partida do Camiño Inglés, cunha rica historia que se reflicte na súa arquitectura e no seu entorno marítimo. Os peregrinos modernos poden gozar dun paseo polo porto, contemplando as vistas do Atlántico, antes de mergullarse na experiencia única desta ruta xacobea.', 'puertoFerrol.jpg', '43°29′04″N 8°13′58″O', 2),
(2, 'Barrio da Magdalena', '10-20', 'humedo', 'O barrio da Magdalena, situado no corazón de Ferrol, é un destacado exemplo de urbanismo neoclásico do século XVIII. Declarado Conxunto Histórico-Artístico, este barrio conxuga a elegancia arquitectónica cun ambiente mariñeiro, sendo unha importante parada para os peregrinos que inician o seu percorrido polo Camiño Inglés.\r\nO deseño do barrio está baseado nun plano ortogonal, con rúas perfectamente aliñadas que lembran a forma dunha barra de chocolate. Os seus edificios, moitos deles coas típicas galerías de vidro galegas, reflicten o carácter industrial e naval da cidade, ao tempo que ofrecen un ambiente acolledor para os camiñantes.\r\nPara os peregrinos, o barrio da Magdalena é un lugar ideal para explorar antes de saír de Ferrol. Aquí podes visitar a Igrexa do Carmen, un fito espiritual, e gozar da hospitalidade local nas súas numerosas prazas, cafés e tabernas. O barrio tamén é un lugar para abastecerse e preparar a estrada.', 'magdalena.jpg', '43º29\'03.7\"N-8º13\'58.2\"W', 2),
(3, 'Ermita de Santa María de Caranza', '10', 'humedo', 'A Ermida de Santa María de Caranza, situada no barrio ferrolán de Caranza, é un lugar de gran valor histórico e espiritual no contexto do Camiño Inglés. Aínda que o edificio actual é unha reconstrución moderna, o lugar ten raíces profundas na tradición xacobea e relixiosa da rexión. Antigamente, esta ermida serviu de referente espiritual e de descanso para os peregrinos que pasaban por Ferrol camiño de Santiago de Compostela. Dedicada á Virxe María, a ermida ofreceu un lugar de oración e recoñecemento, imprescindible para os camiñantes que buscan forzas na súa peregrinación.\r\nO entorno da ermida, próximo á ría de Ferrol, proporciona unha paisaxe tranquila e serena, con vistas á auga e ao entorno natural que rodea a cidade. Este ambiente contribúe á experiencia espiritual do Camiño, proporcionando un momento de pausa e reflexión antes de continuar a ruta.\r\nAínda que hoxe en día a ermida xa non é un centro de actividade de peregrinos como o era antigamente, segue sendo un símbolo do rico patrimonio relixioso de Ferrol e do seu papel histórico na acollida dos camiñantes do Camiño Inglés.', 'ermitaCaranza.jpg', '43°28′51″N 8°13′05″O.', 2),
(4, 'Mosteiro do Couto', '30', 'humedo', 'O Mosteiro de San Martiño de Xuvia, coñecido popularmente como Monasterio do Couto, é unha xoia arquitectónica e espiritual situada en Narón, moi preto de Ferrol. Este mosteiro beneditino, fundado no século XII, é unha parada emblemática do Camiño Inglés, reflectindo a rica historia e devoción que caracterizan esta ruta. Ao longo dos séculos, o Mosteiro do Couto foi un punto de acollida para os peregrinos que percorrían o Camiño Inglés. Os monxes ofrecían abrigo, alimento e consolo espiritual a aqueles que buscaban chegar á tumba do Apóstolo Santiago. Este tramo do camiño, que pasa por verdes paisaxes galegas e pequenas aldeas, ten un significado especial, xa que conecta aos peregrinos co pasado medieval da ruta.\r\nO mosteiro está situado nun entorno natural de gran beleza, preto do río Xuvia. Os peregrinos que pasan por aquí gozan dun momento de paz e contemplación, rodeados da natureza que caracteriza esta parte do Camiño. A zona ofrece un contraste entre a historia e a serenidade da paisaxe, enriquecendo a experiencia do camiñante.', 'monasterioCouto.jpg', '43°32′50″N 8°09′50″O', 2),
(5, 'Casco vello de Neda', '15', 'humedo', 'O Casco Histórico de Neda, un enclave con encanto no corazón desta vila galega, é unha parada destacada do Camiño Inglés. Este pequeno pobo, situado á beira do río Xuvia, foi punto de paso de peregrinos dende a Idade Media, ofrecendo un entorno pintoresco cargado de historia.\r\nNeda foi un centro próspero durante séculos grazas á súa estratéxica situación na ría de Ferrol. O Casco Histórico conserva rúas empedradas, casas tradicionais con balcóns de madeira e varios edificios de interese histórico. Entre elas, destaca a Igrexa de Santa María, de estilo barroco, que foi lugar de culto e descanso dos peregrinos ao longo do tempo. No seu interior hai imaxes de gran valor artístico e devocional, como a Virxe do Rosario.\r\nOutro punto emblemático é a Ponte de Pedra, que cruza o río Xuvia e simboliza a unión entre o camiño histórico e a paisaxe natural que rodea a vila.\r\nO Casco Histórico de Neda foi, e segue a ser, un lugar de gran importancia para os peregrinos. Aquí puidemos recuperar forzas e atopar acollida nos antigos hospitais de peregrinos, como a igrexa de orixe gótica de San Nicolás, que no seu tempo prestaba asistencia aos camiñantes.', 'nedaViejo.jpg', '43°31′15″N 8°09′01″O', 2),
(6, 'Pontedeume', '10', 'humedo', 'Pontedeume, localidade galega situada á beira do río Eume, é un dos puntos máis emblemáticos do Camiño Inglés. Fundada no século XIII por Alfonso X o sabio.\r\nA ponte orixinal, construída en 1380 por iniciativa de Fernán Pérez de Andrade, coñecida como O Bo, foi unha magnífica obra de enxeñería medieval con 68 arcos. Aínda que a ponte foi modificada co paso do tempo, segue sendo parte esencial da paisaxe e testemuña da historia do Camiño Inglés.\r\nO casco histórico de Pontedeume conserva o seu encanto medieval con rúas estreitas, casas con balcóns de madeira e animadas prazas. Destacan varios monumentos importantes, como a Torre dos Andrade, que formaba parte do antigo castelo, e a Igrexa de Santiago, de estilo barroco pero fundada no século XVI, onde moitos peregrinos fan unha pausa para reflexionar ou recibir bendicións no seu camiño.\r\nPontedeume tamén é famosa pola súa rica gastronomía, que inclúe marisco fresco e pratos tradicionais galegos. Para os peregrinos, gozar dunha comida nesta localidade é unha oportunidade para recuperar enerxía e mergullarse na cultura local.', 'pontedeume.jpg', '43°24′36″N 8°10′15″O', 3),
(7, 'Ponte baxoi', '5', 'humedo', 'Ponte Baxoi, unha pequena ponte situada entre as localidades de Miño e Pontedeume, é un destacado punto de paso do Camiño Inglés. Esta ponte medieval, que cruza o río Baxoi, simboliza a continuidade do percorrido e a conexión entre as paisaxes costeiras e rurais que caracterizan esta parte do Camiño.\r\nA Ponte do Baxoi, aínda que de tamaño modesto, ten unha gran importancia histórica. A súa construción orixinal remóntase á Idade Media, e foi pensada para facilitar o tránsito de peregrinos, comerciantes e viaxeiros na súa ruta a Santiago de Compostela. A ponte foi restaurada en varias ocasións, pero aínda conserva elementos arquitectónicos que evocan a súa orixe medieval.\r\nPonte Baxoi non é só un lugar de paso, senón tamén unha testemuña da longa tradición xacobea en Galicia. Ao longo dos séculos, milleiros de peregrinos cruzaron esta ponte, sentindo o peso da historia baixo os seus pés mentres avanzan cara ao seu destino espiritual.\r\nPonte Baxoi sitúase nun punto estratéxico do Camiño Inglés, sendo un recordatorio da importancia das infraestruturas históricas na ruta xacobea. O seu entorno tamén ofrece un respiro antes de afrontar as ladeiras que levan a Pontedeume.', 'ponteBaxoi.jpg', '43°23′19″N 8°08′25″O', 4),
(8, 'Miño', '10', 'humedo', 'Miño, unha encantadora vila costeira da provincia da Coruña, é unha etapa destacada do Camiño Inglés. Situada entre Pontedeume e Betanzos, esta localidade ofrece aos peregrinos un ambiente tranquilo cunha combinación de beleza natural, historia e hospitalidade que enriquece a experiencia xacobea.\r\nMiño é coñecido pola súa cálida acollida aos camiñantes. Aquí, os peregrinos poden gozar dun respiro do esforzo da viaxe, especialmente nos seus albergues e establecementos locais. Ademais, a vila sitúase nun tramo onde as paisaxes costeiras comezan a dar paso aos verdes outeiros do interior, ofrecendo escenarios variados que enriquecen a experiencia do Camiño.', 'mino.jpg', '43°23′04″N 8°11′18″O', 4),
(9, 'Ponte do Porco', '30', 'humedo', 'A Ponte do Porco, situada preto da vila de Miño, é unha ponte medieval que cruza o río Baxoi, afluente da ría de Betanzos. Esta ponte é un dos moitos fitos históricos do Camiño Inglés e foi testemuña de séculos de tránsito de peregrinos que se dirixían a Santiago de Compostela.\r\nO nome \"Ponte do Porco\" ten asociadas varias lendas, aínda que a súa orixe exacta é incerta. Crese que o nome pode derivar dunha antiga tradición de sinalar o cruzamento de porcos dos gandeiros, ou mesmo dunha lenda local relacionada cun \"xabarín\" que apareceu na zona. Porén, a ponte é coñecida desde a Idade Media como un dos pasos importantes para os peregrinos do Camiño Inglés.', 'pontePorco.jpg', '43°21′41″N 8°12′35″O', 4),
(10, 'Iglesia de San Martiño de Tiobre', '50', 'humedo', 'A Igrexa de San Martiño de Tiobre, situada na parroquia de Tiobre, no concello de Betanzos, é un dos puntos máis destacados do Camiño Inglés. Esta igrexa, de gran valor histórico e arquitectónico, foi lugar de descanso e espiritualidade dos peregrinos que percorren esta ruta a Santiago de Compostela.\r\nDurante séculos foi lugar de parada e descanso dos peregrinos que se dirixían a Santiago de Compostela. O templo ofreceu un lugar para a oración, a reflexión e a recuperación de forzas antes de continuar a viaxe.', 'iglesiaSanMartinoTiobre.jpg', '43°29′46″N 8°12′39″O', 4),
(11, 'Betanzos', '20', 'humedo', 'Betanzos, unha das localidades máis importantes da provincia da Coruña, é unha parada histórica do Camiño Inglés. Esta encantadora vila, que combina un rico patrimonio arquitectónico, unha natureza impresionante e unha profunda tradición xacobea, ofrece aos peregrinos unha experiencia única antes de continuar o seu camiño cara a Santiago de Compostela.\r\nAdemais, a cidade acolle varias referencias do Camiño, como o Pórtico da Igrexa de Santa María, que mostra o compromiso de Betanzos coa ruta xacobea. Hoxe, moitos peregrinos seguen pasando por Betanzos gozando do seu ambiente medieval, da súa arquitectura e da súa historia.', 'betanzos.jpg', '43°18′27″N 8°12′31″O', 4),
(12, 'Encoro de Beche', '90', 'humedo', 'O Encoro da Beche, situado na provincia da Coruña, é unha das grandes marabillas naturais que os peregrinos do Camiño Inglés poden atopar no seu percorrido. Este encoro, construído no río Mandeo, ofrece unha paisaxe impresionante e é unha etapa significativa no tramo entre Betanzos e o interior galego.\r\nAínda que o Encoro da Beche non é un punto de paso específico do Camiño Inglés, está situado preto de Betanzos, e o seu entorno natural forma parte da paisaxe que acompaña aos peregrinos. Este encoro é un lugar que moitos camiñantes poden observar no seu camiño, dependendo do percorrido exacto que realicen entre Betanzos e outros puntos próximos do Camiño.', 'embalseBeche.jpg', '43°20′39″N 8°11′27″O', 5),
(13, 'Hospital de Bruma', '300', 'humedo', 'O Hospital Bruma é unha das paradas históricas máis significativas do Camiño Inglés. Situado na parroquia de Bruma, no concello de Ordes, na provincia da Coruña, este antigo hospital medieval era lugar de descanso e acollida dos peregrinos que percorrían esta ruta a Santiago de Compostela.\r\nO Hospital Bruma foi fundado na Idade Media, coa finalidade de ofrecer aloxamento e atención aos peregrinos que percorrían o Camiño Inglés. Naqueles tempos, a ruta xacobea era un camiño longo e arduo, polo que os hospitais eran imprescindibles para proporcionar descanso, alimentación, coidado e protección aos camiñantes. Este hospital medieval formaba parte dunha rede de hospitais e albergues distribuídos ao longo da ruta para garantir a seguridade e o benestar dos peregrinos.', 'hospitalBruma.jpg', '43°11′27″N 8°10′58″O', 5),
(14, 'Sigüeiro', '160', 'humedo', 'Sigüeiro é unha pequena localidade situada no concello de Oroso, na provincia da Coruña, que se atopa no tramo final do Camiño Inglés cara a Santiago de Compostela. Ao longo dos séculos, Sigüeiro foi un lugar clave na ruta xacobea, sobre todo porque está situado preto da cidade de Santiago e ofrece aos peregrinos un lugar de descanso antes de chegar ao seu destino final.\r\nSigüeiro posúe unha longa tradición histórica vinculada ao Camiño de Santiago, xa que era unha importante parada para os peregrinos procedentes da costa, polo Camiño Inglés. Durante a Idade Media, a vila era coñecida polo seu hospital de peregrinos, que ofrecía descanso e asistencia aos camiñantes que se dirixían a Santiago. Actualmente, Sigüeiro segue a ser unha vila ligada ao Camiño, e moitos peregrinos que se achegan a Santiago por esta ruta adoitan facer unha parada na vila para recuperar forzas antes da etapa final cara á cidade compostelá.', 'sigueiro.jpg', '43°10′35″N 8°28′52″O', 6),
(15, 'Bosque Encantado de Formarís', '300', 'humedo', 'O Bosque Encantado de Formarís é unha das marabillas naturais que os peregrinos do Camiño Inglés poden descubrir no seu percorrido por Galicia. Situado na parroquia de Formarís, no concello coruñés de Oroso, este lugar máxico é coñecido pola súa contorna natural chea de lendas e un ambiente que transporta aos camiñantes a outro mundo.\r\nO Bosque Encantado de Formarís é famoso pola súa beleza natural e aura mística. Na Idade Media, a comarca era coñecida polo seu illamento e a súa profunda conexión coa natureza, que lle daban un carácter case espiritual. Aínda que non ten relación directa coa historia medieval do Camiño Inglés, o bosque forma parte da tradición de Galicia, que foi terra de mitos, lendas e antigas crenzas populares, moitos dos cales están asociados ao Camiño de Santiago.\r\nNeste contexto, o Bosque Encantado gañou o seu nome polas historias que circulan sobre el. Dise que o lugar foi testemuña de fenómenos estraños e misteriosos, que atraeu a moita xente a visitalo na procura dunha experiencia única. Para os peregrinos, o Bosque Encantado de Formarís supón unha pausa no camiño para conectar coa natureza galega, mergullándose nunha paisaxe que parece saída dun conto de fadas.', 'bosqueEncantado.jpg', '43°13′21″N 8°17′16″O', 7),
(16, 'Santiago de Compostela', '250', 'humedo', 'Santiago de Compostela, a capital de Galicia, é o destino final non só do Camiño Inglés, senón de todas as rutas de peregrinación do Camiño de Santiago. Declarada Patrimonio da Humanidade pola UNESCO en 1985, a cidade combina historia, espiritualidade e beleza arquitectónica, atraendo cada ano a miles de peregrinos que buscan completar o seu percorrido ante a maxestuosa Catedral de Santiago, onde descansan os restos do apóstolo Santiago o Maior. .\r\nO corazón da cidade é a Catedral de Santiago, obra mestra da arte románica con influencias góticas e barrocas, cuxa construción comezou no século XI. Este templo alberga a tumba do apóstolo Santiago, que se atopa nunha cripta baixo o altar maior. Para os peregrinos, chegar á Catedral e abrazar a estatua do apóstolo é o acto culminante da súa peregrinación.', 'santiago.jpg', '42°53′47″N 8°33′52″O', 7);

-- --------------------------------------------------------

--
-- Estrutura da táboa `proxecto05_rutas`
--

CREATE TABLE `proxecto05_rutas` (
  `id` int NOT NULL,
  `nome` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL,
  `dificultad` enum('facil','medio','dificil') COLLATE utf8mb4_spanish_ci NOT NULL,
  `estado_actual` enum('malo','bo','moi bo') COLLATE utf8mb4_spanish_ci NOT NULL,
  `distancia` float NOT NULL,
  `temporada_recomendada` enum('primaveira','otoño','veran','inverno') COLLATE utf8mb4_spanish_ci NOT NULL,
  `imaxe` varchar(255) COLLATE utf8mb4_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- A extraer os datos da táboa `proxecto05_rutas`
--

INSERT INTO `proxecto05_rutas` (`id`, `nome`, `dificultad`, `estado_actual`, `distancia`, `temporada_recomendada`, `imaxe`) VALUES
(2, 'Ferrol-Neda', 'facil', 'bo', 15, 'veran', 'ferrolNeda.png'),
(3, 'Neda-Pontedeume', 'medio', 'bo', 16, 'veran', 'nedaPontedeume.png'),
(4, 'Pontedeume-Betanzos', 'dificil', 'bo', 21, 'veran', 'pontedeumeBetanzos.png'),
(5, 'Betanzos-Hospital de Bruma', 'dificil', 'bo', 28.3, 'veran', 'betanzosHospital.png'),
(6, 'Hospital de Bruma-Sigüeiro', 'medio', 'bo', 24.8, 'veran', 'hospitalSigueiro.png'),
(7, 'Sigüeiro-Santiago', 'facil', 'bo', 15.5, 'veran', 'sigueiroSantiago.png');

-- --------------------------------------------------------

--
-- Estrutura da táboa `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int NOT NULL,
  `nome` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `apelidos` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `login` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `hashContrasinal` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `rol` enum('administrador','usuario') CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL DEFAULT 'usuario'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- A extraer os datos da táboa `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `apelidos`, `login`, `hashContrasinal`, `email`, `rol`) VALUES
(1, 'Administrador', 'Proxecto Paisaxes', 'admin', '$2y$10$2ueuVBFIAOFZLmNRzCmeMOu2oKJ/twQnLdfvYEoid.RtbVyuLP/WW', 'admin@paisaxes.uchaweb2.es', 'administrador'),
(2, 'Usuario', 'Proxecto Paisaxes', 'ucha', '$2y$10$2ueuVBFIAOFZLmNRzCmeMOu2oKJ/twQnLdfvYEoid.RtbVyuLP/WW', 'usuario@paisaxes.uchaweb2.es', 'usuario');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `proxecto05_comentarios`
--
ALTER TABLE `proxecto05_comentarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `paisaxe_id` (`paisaxe_id`);

--
-- Indexes for table `proxecto05_concellos`
--
ALTER TABLE `proxecto05_concellos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nome_unique` (`nome`),
  ADD UNIQUE KEY `imaxe_unique` (`imaxe`);

--
-- Indexes for table `proxecto05_concello_ruta`
--
ALTER TABLE `proxecto05_concello_ruta`
  ADD KEY `id_concello` (`concello_id`),
  ADD KEY `id_ruta` (`ruta_id`);

--
-- Indexes for table `proxecto05_paisaxes`
--
ALTER TABLE `proxecto05_paisaxes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `imaxe_unique` (`imaxe`),
  ADD UNIQUE KEY `ubicacion_unique` (`ubicacion`),
  ADD UNIQUE KEY `nome_unique` (`nome`),
  ADD KEY `ruta_id` (`ruta_id`);

--
-- Indexes for table `proxecto05_rutas`
--
ALTER TABLE `proxecto05_rutas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nome_unique` (`nome`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `proxecto05_comentarios`
--
ALTER TABLE `proxecto05_comentarios`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `proxecto05_concellos`
--
ALTER TABLE `proxecto05_concellos`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `proxecto05_paisaxes`
--
ALTER TABLE `proxecto05_paisaxes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `proxecto05_rutas`
--
ALTER TABLE `proxecto05_rutas`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restricións para os envorcados das táboas
--

--
-- Restricións para a táboa `proxecto05_comentarios`
--
ALTER TABLE `proxecto05_comentarios`
  ADD CONSTRAINT `proxecto05_comentarios_ibfk_1` FOREIGN KEY (`paisaxe_id`) REFERENCES `proxecto05_paisaxes` (`id`);

--
-- Restricións para a táboa `proxecto05_concello_ruta`
--
ALTER TABLE `proxecto05_concello_ruta`
  ADD CONSTRAINT `proxecto05_concello_ruta_ibfk_1` FOREIGN KEY (`concello_id`) REFERENCES `proxecto05_concellos` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `proxecto05_concello_ruta_ibfk_2` FOREIGN KEY (`ruta_id`) REFERENCES `proxecto05_rutas` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Restricións para a táboa `proxecto05_paisaxes`
--
ALTER TABLE `proxecto05_paisaxes`
  ADD CONSTRAINT `proxecto05_paisaxes_ibfk_1` FOREIGN KEY (`ruta_id`) REFERENCES `proxecto05_rutas` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
