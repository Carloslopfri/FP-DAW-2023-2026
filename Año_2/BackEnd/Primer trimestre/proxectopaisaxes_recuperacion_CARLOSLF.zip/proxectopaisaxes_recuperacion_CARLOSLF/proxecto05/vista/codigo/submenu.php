<?php
/*

    @Título: Proxecto Paisaxe e sustentabilidade - Subproxecto 05
    
    @Autor: Carlos López Frieiro

    @Data modificación: 06/02/2025

    @Versión 1.1

*/
?>
<nav class="navbar-secundaria navbar-expand-lg navbar-light mb-3">
    <div class="container-fluid">
        <span class="subproxecto-titulo me-auto">Atlas de paisaxes do Camiño Inglés</span>

        <button style="color: #FFF" class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSecundario" aria-controls="navbarSecundario" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div id="navbarSecundario" class="collapse navbar-collapse">
            <!-- Opcións do menú á dereita -->
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="./../../index.php">Parte pública</a>
                </li>
                <?php if (isset($_SESSION['usuario']) && ($_SESSION['usuario']->rol == 'administrador')) { ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="adminMenu" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Administración
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="./fichaCRUDpaisaxes.php">Paisaxes</a></li>
                            <li><a class="dropdown-item" href="./fichaCRUDetapas.php">Etapas</a></li>
                            <li><a class="dropdown-item" href="./fichaCRUDconcellos.php">Concellos</a></li>
                            <li><a class="dropdown-item" href="./fichaCRUDcomentarios.php">Comentarios</a></li>
                        </ul>
                    </li>
                <?php } ?>
            </ul>
        </div>
    </div>
</nav>

