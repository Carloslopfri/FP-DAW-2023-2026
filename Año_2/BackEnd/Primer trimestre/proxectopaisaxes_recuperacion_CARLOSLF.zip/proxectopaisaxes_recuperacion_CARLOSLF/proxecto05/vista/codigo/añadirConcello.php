<?php
/*

    @Título: Proxecto Paisaxe e sustentabilidade - Subproxecto 05
    
    @Autor: Carlos López Frieiro

    @Data modificación: 06/02/2025

    @Versión 1.1

*/

require_once './../../controlador/ControlRutas.class.php';
require_once './../../controlador/ControlConcellos.class.php';
require_once('./../../../../modelo/Usuario.class.php');
session_start();
if ($_SESSION['usuario']->rol != 'administrador') {
    header('Location: ../../index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../../../../vista/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../../../vista/css/app.css">
    <link rel="stylesheet" href="../styles/añadirPaisaxe.css" type="text/css">
    <title>CIFP Rodolfo Ucha Piñeiro :: Proxecto Paisaxe e sustentabilidade</title>
</head>

<body>
    <header>
        <div class="my-0 d-flex justify-content-center" style="margin: 0; padding: 0;">
            <a href="./../../../../index.php" style="margin: 0; padding: 0;">
                <img src="../../../../vista/imx/logo-proxecto-paisaxe_final.png" alt="Logo Proxecto Paisaxe" class="img-fluid" style="margin: 0.5rem; padding: 0;max-width: 400px; height: 150px;">
            </a>
        </div>
        <?php $ruta = ""; ?>
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">

                <button style="color: #FFF" class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div id="navbarNav" class="collapse navbar-collapse justify-content-center">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="../../../../index.php">Contribucións</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../../../../presentacion.php">Presentación</a>
                        </li>
                        <?php if (isset($_SESSION['usuario'])) { ?>
                            <li class="nav-item">
                                <a class="nav-link" href="../../../../sair.php">Saír</a>
                            </li>
                        <?php } else { ?>
                            <li class="nav-item">
                                <a class="nav-link" href="../../../../login.php">Acceder</a>
                            </li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </nav>
        <?php include('submenu.php'); ?>
        <?php
        $controlrt = new ControlRt();
        $rutas = $controlrt->mostrarRutas();
        $controlcll = new ControlCll();
        ?>
    </header>
    <div class="contenedor">
        <form action="añadirConcello.php" method="post" enctype="multipart/form-data" class="formulario">
            <h3>Engade un concello completando o formulario:</h3>
            <?php
            if (isset($_POST['engadir'])) {
                $textNome = $_POST['nome'];
                $textProvincia = $_POST['provincia'];
                $textImaxe = $_FILES['imaxe'];
                $textPoboacion = $_POST['poboacion'];
                $textSuperficie = $_POST['superficie'];
                $textRutaId = $_POST['ruta_id'];
                $resultado = $controlcll->validarFormularioAñadirConcello($textNome, $textProvincia, $textImaxe, $textPoboacion, $textSuperficie, $textRutaId);
                if ($resultado === true) { ?>
                    <b style=color:green>O concello foi engadido con éxito.</b>
            <?php } else {
                    foreach ($resultado as $error) {
                        echo $error;
                    }
                }
            }
            ?>
            <label for="nome">Nome: </label>
            <input type="text" id="nome" name="nome">

            <label for="provincia">Provincia:</label>
            <input type="text" id="provincia" name="provincia">

            <label for="imaxe">Imaxe:</label>
            <input type="file" name="imaxe" id="imaxe">

            <label for="poboacion">Poboación:</label>
            <input type="text" name="poboacion" id="poboacion">

            <label for="superficie">Superficie:</label>
            <input type="text" name="superficie" id="superficie">

            <label for="ruta_id">Etapa:</label>
            <select name="ruta_id[]" id="ruta_id" multiple>
                <?php
                foreach ($rutas as $ruta) { ?>
                    <option value="<?php echo $ruta->id; ?>"><?php echo $ruta->nome; ?></option>'
                <?php } ?>
            </select>

            <button name="engadir" type="submit">Engadir</button>
        </form>
    </div>

    <!-- Pé de páxina -->
    <footer class="py-4">
        <div class="container text-center">
            <hr class="border-top border-3 border-secondary my-4 hr-personalizado">
        </div>

        <div class="container text-center">
            <p>&copy; <span id="currentYear"><?php echo date("Y"); ?></span> - CIFP Rodolfo Ucha Piñeiro</p>
        </div>
    </footer>
    <!-- Fin Pé de páxina -->
    <script src="../../../../vista/js/bootstrap.bundle.min.js"></script>
</body>

</html>