<?php
/*

    @Título: Proxecto Paisaxe e sustentabilidade - Subproxecto 05
    
    @Autor: Carlos López Frieiro

    @Data modificación: 06/02/2025

    @Versión 1.1

*/

require_once './../../controlador/ControlPaisaxes.class.php';
require_once './../../controlador/ControlComentarios.class.php';
require_once('./../../../../modelo/Usuario.class.php');
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../../../../vista/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../../../vista/css/app.css">
    <link rel="stylesheet" href="../styles/fichaComentarios.css" type="text/css">
    <title>CIFP Rodolfo Ucha Piñeiro :: Proxecto Paisaxe e sustentabilidade</title>
</head>

<body>
    <header>
        <div class="my-0 d-flex justify-content-center" style="margin: 0; padding: 0;">
            <a href="./../../../../index.php" style="margin: 0; padding: 0;">
                <img src="../../../../vista/imx/logo-proxecto-paisaxe_final.png" alt="Logo Proxecto Paisaxe" class="img-fluid" style="margin: 0.5rem; padding: 0;max-width: 400px; height: 150px;">
            </a>
        </div>
        <?php $ruta = ""; ?>
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">

                <button style="color: #FFF" class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div id="navbarNav" class="collapse navbar-collapse justify-content-center">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="../../../../index.php">Contribucións</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../../../../presentacion.php">Presentación</a>
                        </li>
                        <?php if (isset($_SESSION['usuario'])) { ?>
                            <li class="nav-item">
                                <a class="nav-link" href="../../../../sair.php">Saír</a>
                            </li>
                        <?php } else { ?>
                            <li class="nav-item">
                                <a class="nav-link" href="../../../../login.php">Acceder</a>
                            </li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </nav>
        <?php include('submenu.php'); ?>
        <?php
        $id = $_GET['id'];
        $controlpsx = new ControlPsx();
        $controlcmt = new ControlCmt();
        $paisaxe = $controlpsx->mostrarPaisaxe($id);
        $comentarios = $controlcmt->mostrarComentariosPaisaxe($id);
        ?>
    </header>
    <div class="titulo">
        <h3>Comenatrios da paisaxe: <?php echo $paisaxe->nome; ?></h3>
    </div>
    <div class="contenedor">
        <?php if (!count($comentarios) < 1) { ?>
            <table>
                <tr>
                    <th>Data</th>
                    <th>Contido</th>
                    <th>&#11088;</th>
                    <th>&#128077;</th>
                </tr>
                <?php foreach ($comentarios as $comentario) { ?>
                    <tr>
                        <td><?php echo $comentario->data ?></td>
                        <td><?php echo $comentario->contido ?></td>
                        <td><?php echo $comentario->puntuacion ?></td>
                        <td><?php echo $comentario->likes ?></td>
                    </tr>
                <?php } ?>
            </table>
        <?php } else { ?>
            <h5 style="color:green">Ninguén comentou ainda, podes ser o primeiro &#128522;.</h5>
        <?php } ?>
    </div>
    <div class="botones">
        <a href="crearComentario.php?id=<?php echo $id; ?>" style="color:green; margin-right:50px">Añadir comentario</a>
        <a href="./fichaPaisaxe.php?id=<?php echo $id; ?>" style="color:green; margin-right:50px">Volver á paxina da paisaxe</a>
        <a href="../../index.php" style="color:green">Volver á páxina principal</a>
    </div>

    <!-- Pé de páxina -->
    <footer class="py-4">
        <div class="container text-center">
            <hr class="border-top border-3 border-secondary my-4 hr-personalizado">
        </div>

        <div class="container text-center">
            <p>&copy; <span id="currentYear"><?php echo date("Y"); ?></span> - CIFP Rodolfo Ucha Piñeiro</p>
        </div>
    </footer>
    <!-- Fin Pé de páxina -->
    <script src="../../../../vista/js/bootstrap.bundle.min.js"></script>
</body>

</html>