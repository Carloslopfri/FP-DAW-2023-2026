<?php
/*

    @Título: Proxecto Paisaxe e sustentabilidade - Subproxecto 05
    
    @Autor: Carlos López Frieiro

    @Data modificación: 06/02/2025

    @Versión 1.1

*/

require_once './../../controlador/ControlRutas.class.php';
require_once './../../controlador/ControlPaisaxes.class.php';
require_once('./../../../../modelo/Usuario.class.php');
session_start();
if ($_SESSION['usuario']->rol != 'administrador') {
    header('Location: ../../index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../../../../vista/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../../../vista/css/app.css">
    <link rel="stylesheet" href="../styles/añadirPaisaxe.css" type="text/css">
    <title>CIFP Rodolfo Ucha Piñeiro :: Proxecto Paisaxe e sustentabilidade</title>
</head>

<body>
    <header>
        <div class="my-0 d-flex justify-content-center" style="margin: 0; padding: 0;">
            <a href="./../../../../index.php" style="margin: 0; padding: 0;">
                <img src="../../../../vista/imx/logo-proxecto-paisaxe_final.png" alt="Logo Proxecto Paisaxe" class="img-fluid" style="margin: 0.5rem; padding: 0;max-width: 400px; height: 150px;">
            </a>
        </div>
        <?php $ruta = ""; ?>
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">

                <button style="color: #FFF" class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div id="navbarNav" class="collapse navbar-collapse justify-content-center">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="../../../../index.php">Contribucións</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../../../../presentacion.php">Presentación</a>
                        </li>
                        <?php if (isset($_SESSION['usuario'])) { ?>
                            <li class="nav-item">
                                <a class="nav-link" href="../../../../sair.php">Saír</a>
                            </li>
                        <?php } else { ?>
                            <li class="nav-item">
                                <a class="nav-link" href="../../../../login.php">Acceder</a>
                            </li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </nav>
        <?php include('submenu.php'); ?>
        <?php
        $id = $_GET['id'];
        $controlrt = new ControlRt();
        $rutas = $controlrt->mostrarRutas();
        $controlpsx = new ControlPsx();
        $paisaxe = $controlpsx->mostrarPaisaxe($id);
        ?>
    </header>
    <div class="contenedor">
        <form action="modificarPaisaxe.php?id=<?php echo $id; ?>" method="post" enctype="multipart/form-data" class="formulario">
            <h3>Engade unha paisaxe completando o formulario:</h3>
            <?php
            if (isset($_POST['modificar'])) {
                $textNome = $_POST['nome'];
                $textAltitud = $_POST['altitud'];
                $textClima = $_POST['clima'];
                $textDescripcion = $_POST['descripcion'];
                $textImaxe = $_FILES['imaxe'];
                $textUbicacion = $_POST['ubicacion'];
                $textRutaId = $_POST['ruta_id'];
                $resultado = $controlpsx->validarFormularioModificarPaisaxe($id, $textNome, $textAltitud, $textClima, $textDescripcion, $textImaxe, $textUbicacion, $textRutaId);
                if ($resultado === true) { ?>
                    <b style=color:green>A paisaxe foi modificada con éxito.</b>
            <?php } else {
                    foreach ($resultado as $error) {
                        echo $error;
                    }
                }
            }
            ?>
            <label for="nome"><b>Nome:</b></label>
            <input type="text" id="nome" name="nome" value="<?php echo $paisaxe->nome; ?>">

            <label for="altitud"><b>Altitude (en metros a nivel del mar):</b></label>
            <input type="text" id="altitud" name="altitud" value="<?php echo $paisaxe->altitud; ?>">

            <label for="clima"><b>Clima:</b></label>
            <select name="clima" id="clima">
                <option value="humedo" <?php if ($paisaxe->clima == 'humedo') {
                                            echo 'selected';
                                        } ?>>Húmedo</option>
                <option value="seco" <?php if ($paisaxe->clima == 'seco') {
                                            echo 'selected';
                                        } ?>>Seco</option>
            </select>

            <label for="descripcion"><b>Descrición:</b></label>
            <textarea name="descripcion" id="descripcion"><?php echo $paisaxe->descripcion; ?></textarea>

            <label for="imaxe"><b>Imaxe:</b></label>
            <input type="file" id="imaxe" name="imaxe" class="fichero">

            <label for="ubicacion"><b>Coordenadas:</b></label>
            <input type="text" name="ubicacion" id="ubicacion" value="<?php echo $paisaxe->ubicacion; ?>">

            <label for="ruta_id"><b>Etapa:</b></label>
            <select name="ruta_id" id="ruta_id">
                <?php
                foreach ($rutas as $ruta) {
                    if ($paisaxe->ruta_id == $ruta->id) {
                        $selecionado = 'selected';
                    } else {
                        $selecionado = '';
                    }
                    echo '<option value="' . $ruta->id . '" ' . $selecionado . '>' . $ruta->nome . '</option>';
                }
                ?>
            </select>

            <button name="modificar" type="submit" style="width: 100px;">Modificar</button>
        </form>
    </div>

    <!-- Pé de páxina -->
    <footer class="py-4">
        <div class="container text-center">
            <hr class="border-top border-3 border-secondary my-4 hr-personalizado">
        </div>

        <div class="container text-center">
            <p>&copy; <span id="currentYear"><?php echo date("Y"); ?></span> - CIFP Rodolfo Ucha Piñeiro</p>
        </div>
    </footer>
    <!-- Fin Pé de páxina -->
    <script src="../../../../vista/js/bootstrap.bundle.min.js"></script>
</body>

</html>