<?php
/*

    @Título: Proxecto Paisaxe e sustentabilidade - Subproxecto 05
    
    @Autor: Carlos López Frieiro

    @Data modificación: 06/02/2025

    @Versión 1.1

*/

require_once './../../controlador/ControlRutas.class.php';
require_once './../../controlador/ControlConcellos.class.php';
require_once('./../../../../modelo/Usuario.class.php');
session_start();
if ($_SESSION['usuario']->rol != 'administrador') {
    header('Location: ../../index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../../../../vista/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../../../vista/css/app.css">
    <link rel="stylesheet" href="../styles/añadirPaisaxe.css" type="text/css">
    <title>CIFP Rodolfo Ucha Piñeiro :: Proxecto Paisaxe e sustentabilidade</title>
</head>

<body>
    <header>
        <div class="my-0 d-flex justify-content-center" style="margin: 0; padding: 0;">
            <a href="./../../../../index.php" style="margin: 0; padding: 0;">
                <img src="../../../../vista/imx/logo-proxecto-paisaxe_final.png" alt="Logo Proxecto Paisaxe" class="img-fluid" style="margin: 0.5rem; padding: 0;max-width: 400px; height: 150px;">
            </a>
        </div>
        <?php $ruta = ""; ?>
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">

                <button style="color: #FFF" class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div id="navbarNav" class="collapse navbar-collapse justify-content-center">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="../../../../index.php">Contribucións</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../../../../presentacion.php">Presentación</a>
                        </li>
                        <?php if (isset($_SESSION['usuario'])) { ?>
                            <li class="nav-item">
                                <a class="nav-link" href="../../../../sair.php">Saír</a>
                            </li>
                        <?php } else { ?>
                            <li class="nav-item">
                                <a class="nav-link" href="../../../../login.php">Acceder</a>
                            </li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </nav>
        <?php include('submenu.php'); ?>
        <?php
        $control = new ControlRt();
        $rutas = $control->mostrarRutas();
        $controlCll = new ControlCll();
        $concellos = $controlCll->mostrarConcellos();
        ?>
    </header>
    <div class="contenedor">
        <form action="añadirRuta.php" method="post" enctype="multipart/form-data" class="formulario">
            <h3>Engade unha etapa completando o formulario:</h3>
            <?php
            if (isset($_POST['engadir'])) {
                $textNome = $_POST['nome'];
                $textDificultad = $_POST['dificultad'];
                $textEstadoActual = $_POST['estado_actual'];
                $textDistancia = $_POST['distancia'];
                $textTemporada = $_POST['temporada'];
                $textImaxe = $_FILES['imaxe'];
                $textConcellos = $_POST['concellos'];
                $resultado = $control->validarFormularioAñadirRuta($textNome, $textDificultad, $textEstadoActual, $textDistancia, $textTemporada, $textImaxe, $textConcellos);
                if ($resultado === true) { ?>
                    <b style=color:green>A etapa foi engadida con éxito.</b>
            <?php } else {
                    foreach ($resultado as $error) {
                        echo $error;
                    }
                }
            }
            ?>
            <label for="nome">Nome: </label>
            <input type="text" id="nome" name="nome">

            <label for="dificultad">Dificultade:</label>
            <select name="dificultad" id="dificultad">
                <option value=""></option>
                <option value="facil">facil</option>
                <option value="medio">Medio</option>
                <option value="dificil">Dificil</option>
            </select>

            <label for="estado_actual">Estado actual:</label>
            <select name="estado_actual" id="estado_actual">
                <option value=""></option>
                <option value="malo">Malo</option>
                <option value="bo">Bo</option>
                <option value="moi bo">Moi bo</option>
            </select>

            <label for="distancia">Distancia:</label>
            <input type="text" id="distancia" name="distancia">

            <label for="temporada">Temporada recomendada:</label>
            <select name="temporada" id="temporada">
                <option value=""></option>
                <option value="primaveira">Primaveira</option>
                <option value="otoño">Otoño</option>
                <option value="veran">Verán</option>
                <option value="inverno">Inverno</option>
            </select>

            <label for="imaxe">Imaxe:</label>
            <input type="file" id="imaxe" name="imaxe" class="fichero">

            <label for="concellos">Concellos onde pertence á ruta:</label>
            <select name="concellos[]" id="concellos" multiple>
                <?php foreach($concellos as $concello) { ?>
                    <option value="<?php echo $concello->id; ?>"><?php echo $concello->nome; ?></option>
                <?php } ?>
            </select>

            <button name="engadir" type="submit">Engadir</button>
        </form>
    </div>

    <!-- Pé de páxina -->
    <footer class="py-4">
        <div class="container text-center">
            <hr class="border-top border-3 border-secondary my-4 hr-personalizado">
        </div>

        <div class="container text-center">
            <p>&copy; <span id="currentYear"><?php echo date("Y"); ?></span> - CIFP Rodolfo Ucha Piñeiro</p>
        </div>
    </footer>
    <!-- Fin Pé de páxina -->
    <script src="../../../../vista/js/bootstrap.bundle.min.js"></script>
</body>

</html>