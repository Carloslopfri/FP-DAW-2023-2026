<?php
/*

    @Título: Proxecto Paisaxe e sustentabilidade - Subproxecto 05
    
    @Autor: Carlos López Frieiro

    @Data modificación: 06/02/2025

    @Versión 1.1

*/

require_once './../../controlador/ControlPaisaxes.class.php';
require_once('./../../../../modelo/Usuario.class.php');
session_start();
if ($_SESSION['usuario']->rol != 'administrador') {
    header('Location: ../../index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../../../../vista/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../../../vista/css/app.css">
    <link rel="stylesheet" href="../styles/fichaComentarios.css" type="text/css">
    <title>CIFP Rodolfo Ucha Piñeiro :: Proxecto Paisaxe e sustentabilidade</title>
</head>

<body>
    <header>
        <div class="my-0 d-flex justify-content-center" style="margin: 0; padding: 0;">
            <a href="./../../../../index.php" style="margin: 0; padding: 0;">
                <img src="../../../../vista/imx/logo-proxecto-paisaxe_final.png" alt="Logo Proxecto Paisaxe" class="img-fluid" style="margin: 0.5rem; padding: 0;max-width: 400px; height: 150px;">
            </a>
        </div>
        <?php $ruta = ""; ?>
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">

                <button style="color: #FFF" class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div id="navbarNav" class="collapse navbar-collapse justify-content-center">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="../../../../index.php">Contribucións</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../../../../presentacion.php">Presentación</a>
                        </li>
                        <?php if (isset($_SESSION['usuario'])) { ?>
                            <li class="nav-item">
                                <a class="nav-link" href="../../../../sair.php">Saír</a>
                            </li>
                        <?php } else { ?>
                            <li class="nav-item">
                                <a class="nav-link" href="../../../../login.php">Acceder</a>
                            </li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </nav>
        <?php include('submenu.php'); ?>
        <?php
        $control = new ControlPsx();
        $paisaxes = $control->mostrarPaisaxes();
        ?>
    </header>
    <div class="titulo">
        <h3>Tabla Paisaxes</h3>
    </div>
    <div class="contenedor">
        <?php if (!count($paisaxes) < 1) { ?>
            <table>
                <tr>
                    <th>Id</th>
                    <th>Nome</th>
                    <th>Altitude</th>
                    <th>Clima</th>
                    <th>Descrición</th>
                    <th>Imaxe</th>
                    <th>Ubicación</th>
                    <th>ID Ruta</th>
                    <th>Accións</th>
                </tr>
                <?php foreach ($paisaxes as $paisaxe) { ?>
                    <tr>
                        <td><?php echo $paisaxe->id; ?></td>
                        <td><?php echo $paisaxe->nome; ?></td>
                        <td><?php echo $paisaxe->altitud; ?></td>
                        <td><?php echo $paisaxe->clima; ?></td>
                        <td><?php echo $paisaxe->descripcion; ?></td>
                        <td><?php echo $paisaxe->imaxe; ?></td>
                        <td><?php echo $paisaxe->ubicacion; ?></td>
                        <td><?php echo $paisaxe->ruta_id; ?></td>
                        <td><a href="../../controlador/borrarPaisaxe.php?id=<?php echo $paisaxe->id; ?>" style="color:green">Borrar</a> <a href="modificarPaisaxe.php?id=<?php echo $paisaxe->id; ?>" style="color:green">Modificar</a></td>
                    </tr>
                <?php } ?>
            </table>
        <?php } else { ?>
            <h5 style="color:green">Non se atopou a tabla de paisaxes.</h5>
        <?php } ?>
    </div>
    <div class="botones">
        <a href="añadirPaisaxe.php" style="color:green; margin-right: 50px">Engadir paisaxe</a>
        <a href="../../index.php" style="color:green">Volver á páxina principal</a>
    </div>

    <!-- Pé de páxina -->
    <footer class="py-4">
        <div class="container text-center">
            <hr class="border-top border-3 border-secondary my-4 hr-personalizado">
        </div>

        <div class="container text-center">
            <p>&copy; <span id="currentYear"><?php echo date("Y"); ?></span> - CIFP Rodolfo Ucha Piñeiro</p>
        </div>
    </footer>
    <!-- Fin Pé de páxina -->
    <script src="../../../../vista/js/bootstrap.bundle.min.js"></script>
</body>

</html>