<?php
/*

    @Título: Proxecto Paisaxe e sustentabilidade - Subproxecto 05
    
    @Autor: Carlos López Frieiro

    @Data modificación: 06/02/2025

    @Versión 1.1

*/

require_once './../../controlador/ControlRutas.class.php';
require_once './../../controlador/ControlConcellos.class.php';
require_once('./../../../../modelo/Usuario.class.php');
session_start();
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../../../../vista/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../../../vista/css/app.css">
    <link rel="stylesheet" href="../styles/ficha.css" type="text/css">
    <title>CIFP Rodolfo Ucha Piñeiro :: Proxecto Paisaxe e sustentabilidade</title>
</head>

<body>
    <header>
        <div class="my-0 d-flex justify-content-center" style="margin: 0; padding: 0;">
            <a href="./../../../../index.php" style="margin: 0; padding: 0;">
                <img src="../../../../vista/imx/logo-proxecto-paisaxe_final.png" alt="Logo Proxecto Paisaxe" class="img-fluid" style="margin: 0.5rem; padding: 0;max-width: 400px; height: 150px;">
            </a>
        </div>
        <?php $ruta = ""; ?>
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">

                <button style="color: #FFF" class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div id="navbarNav" class="collapse navbar-collapse justify-content-center">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="../../../../index.php">Contribucións</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../../../../presentacion.php">Presentación</a>
                        </li>
                        <?php if (isset($_SESSION['usuario'])) { ?>
                            <li class="nav-item">
                                <a class="nav-link" href="../../../../sair.php">Saír</a>
                            </li>
                        <?php } else { ?>
                            <li class="nav-item">
                                <a class="nav-link" href="../../../../login.php">Acceder</a>
                            </li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </nav>
        <?php include('submenu.php'); ?>
        <?php
        $idRuta = $_GET['idR'];
        $idPaisaxe = $_GET['idP'];
        $controlrt = new ControlRt();
        $controlcll = new ControlCll();
        $ruta = $controlrt->mostrarRuta($idRuta);
        $concellos = $controlcll->mostrarConcellosRuta($idRuta);
        ?>
    </header>
    <div class="foto">
        <img src="./../img/<?php echo $ruta->imaxe; ?>" alt="imagen" class="imagen">
    </div>
    <div class="info">
        <h4>Características da etapa <?php echo $ruta->nome; ?></h4>
        <ul>
            <li>A dificultade da etepa é <?php echo $ruta->dificultad; ?>.</li>
            <li>O estado actual da etapa é <?php echo $ruta->estado_actual; ?>.</li>
            <li>A distancia é de <?php echo $ruta->distancia; ?> km.</li>
            <li>A mellor estación para facer esta etapa é <?php echo $ruta->temporada_recomendada; ?>.</li>
            <li>Esta etapa pertence a os seguintes concellos: <?php
                                                                if (!count($concellos) < 1) {
                                                                    foreach ($concellos as $concello) { ?>
                        <a href="fichaConcello.php?idC=<?php echo $concello->id ?>&idR=<?php echo $idRuta ?>&idP=<?php echo $idPaisaxe ?>" style="color:green"><?php echo $concello->nome ?></a>
                    <?php }
                                                                } else { ?>
                    <p style="color:green">Non se atoparon concellos</p>
                <?php }
                ?>
            </li>
        </ul>
        <a href="fichaPaisaxe.php?id=<?php echo $idPaisaxe; ?>" style="color:green; margin-right: 80px">Volver á páxina da paisaxe</a>
        <a href="../../index.php" style="color:green">Volver á páxina principal</a>
    </div>

    <!-- Pé de páxina -->
    <footer class="py-4">
        <div class="container text-center">
            <hr class="border-top border-3 border-secondary my-4 hr-personalizado">
        </div>

        <div class="container text-center">
            <p>&copy; <span id="currentYear"><?php echo date("Y"); ?></span> - CIFP Rodolfo Ucha Piñeiro</p>
        </div>
    </footer>
    <!-- Fin Pé de páxina -->
    <script src="../../../../vista/js/bootstrap.bundle.min.js"></script>
</body>

</html>