<?php
/*

    @Título: Proxecto Paisaxe e sustentabilidade - Subproxecto 05
    
    @Autor: Carlos López Frieiro

    @Data modificación: 06/02/2025

    @Versión 1.1

*/

include_once './controlador/ControlPaisaxes.class.php';
include_once('../../modelo/Usuario.class.php');
session_start();
$control = new ControlPsx();
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../../vista/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../vista/css/app.css">
    <link rel="stylesheet" href="./vista/styles/index.css" type="text/css">
    <title>CIFP Rodolfo Ucha Piñeiro :: Proxecto Paisaxe e sustentabilidade</title>
</head>

<body>
    <header>
        <?php
        $currentUrl = $_SERVER['REQUEST_URI'];
        if (strpos($currentUrl, '/subproxectos/') !== false) {
            $ruta = "../../";
        } else {
            $ruta = "./";
        }
        ?>
        <div class="my-0 d-flex justify-content-center" style="margin: 0; padding: 0;">
            <a href="../../index.php" style="margin: 0; padding: 0;">
                <img src="<?php echo $ruta; ?>vista/imx/logo-proxecto-paisaxe_v2.png" alt="Logo Proxecto Paisaxe" class="img-fluid" style="margin: 0.5rem; padding: 0;max-width: 400px; height: 150px;">
            </a>
        </div>

        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">

                <button style="color: #FFF" class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div id="navbarNav" class="collapse navbar-collapse justify-content-center">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo $ruta; ?>index.php">Contribucións</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo $ruta; ?>presentacion.php">Presentación</a>
                        </li>
                        <?php if (isset($_SESSION['usuario'])) { ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo $ruta; ?>sair.php">Saír</a>
                            </li>
                        <?php } else { ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo $ruta; ?>login.php">Acceder</a>
                            </li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </nav>

        <nav class="navbar-secundaria navbar-expand-lg navbar-light mb-3">
            <div class="container-fluid">
                <span class="subproxecto-titulo me-auto">Atlas de paisaxes do Camiño Inglés</span>

                <button style="color: #FFF" class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSecundario" aria-controls="navbarSecundario" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div id="navbarSecundario" class="collapse navbar-collapse">
                    <!-- Opcións do menú á dereita -->
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="./index.php">Parte pública</a>
                        </li>
                        <?php if (isset($_SESSION['usuario']) && ($_SESSION['usuario']->rol == 'administrador')) { ?>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="adminMenu" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    Administración
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="./vista/codigo/fichaCRUDpaisaxes.php">Paisaxes</a></li>
                                    <li><a class="dropdown-item" href="./vista/codigo/fichaCRUDetapas.php">Etapas</a></li>
                                    <li><a class="dropdown-item" href="./vista/codigo/fichaCRUDconcellos.php">Concellos</a></li>
                                    <li><a class="dropdown-item" href="./vista/codigo/fichaCRUDcomentarios.php">Comentarios</a></li>
                                </ul>
                            </li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <div class="mapa">
        <img src="./vista/img/caminoIngles.png" alt="imagen" class="imagen">
    </div>
    <div class="lista">
        <h4 style="margin-left:15px">Paisaxes:</h4>
        <ol>
            <?php
            $paisaxes = $control->mostrarPaisaxes();
            foreach ($paisaxes as $paisaxe) { ?>
                <li><a href="./vista/codigo/fichaPaisaxe.php?id=<?php echo $paisaxe->id ?>" style="color:green"><?php echo $paisaxe->nome ?></a></li>
            <?php } ?>
        </ol>
    </div>
    <?php include('../../vista/layout/pe.php'); ?>
</body>

</html>