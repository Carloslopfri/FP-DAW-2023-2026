<?php
/*

    @Título: Proxecto Paisaxe e sustentabilidade - Subproxecto 05
    
    @Autor: Carlos López Frieiro

    @Data modificación: 06/02/2025

    @Versión 1.1

*/

include './ControlComentarios.class.php';
$id = $_GET['id'];
$control = new ControlCmt();
$control->eliminarComentario($id);
header('Location: ../vista/codigo/fichaCRUDcomentarios.php');
exit();
