<?php
/*

    @Título: Proxecto Paisaxe e sustentabilidade - Subproxecto 05
    
    @Autor: Carlos López Frieiro

    @Data modificación: 06/02/2025

    @Versión 1.1

*/

require_once __DIR__ . '/../modelo/DAO.class.php';

class ControlRt {
    public function mostrarRuta($id)
    {
        $dao = new DAO_class();
        $ruta = $dao->obtenerRuta($id);
        return $ruta;
    }

    public function mostrarRutas()
    {
        $dao = new DAO_class();
        $rutas = $dao->obtenerRutas();
        return $rutas;
    }

    public function validarFormularioAñadirRuta($nome, $dificultad, $estado_actual, $distancia, $temporada, $imaxe, $idsConcellos)
    {
        $nomeCorrecto = false;
        $dificultadCorrecto = false;
        $estado_actualCorrecto = false;
        $distanciaCorrecto = false;
        $imaxeCorrecto = false;
        $concellosCorrecto = false;

        $errores = [];

        if (empty($nome)) {
            array_push($errores, '<p style="color:red">O campo do nome non pode estar baleiro.</p>');
        } else if (strlen($nome) > 30) {
            array_push($errores, '<p style="color:red">O campo do nome non pode superar os 30 caracteres.</p>');
        } else {
            $nomeCorrecto = true;
        }

        if ($dificultad == '') {
            array_push($errores, '<p style="color:red">O apartado de dificultade non pode estar baleiro.</p>');
        } else {
            $dificultadCorrecto = true;
        }

        if ($estado_actual == '') {
            array_push($errores, '<p style="color:red">O apartado de estado actual non pode estar baleiro.</p>');
        } else {
            $estado_actualCorrecto = true;
        }

        if (empty($distancia)) {
            array_push($errores, '<p style="color:red">O apartado de distancia non pode estar baleiro.</p>');
        } else if (!is_numeric($distancia)) {
            array_push($errores, '<p style="color:red">O apartado de distancia ten que ter un valor numérico.</p>');
        } else if ($distancia > 100) {
            array_push($errores, '<p style="color:red">O apartado de distancia non pode superar os 100 km.</p>');
        } else {
            $distanciaCorrecto = true;
        }

        if (!isset($imaxe)) {
            array_push($errores, '<p style = "color:red">O campo da imaxe é obrigatorio.</p>');
        } else {
            $imaxeCorrecto = true;
        }

        if (empty($idsConcellos)) {
            array_push($errores, '<p style = "color:red">O campo de concellos é obrigatorio.</p>');
        } else {
            $concellosCorrecto = true;
        }

        if ($nomeCorrecto == true && $dificultadCorrecto == true && $estado_actualCorrecto == true && $distanciaCorrecto == true && $imaxeCorrecto == true && $concellosCorrecto == true) {
            if (isset($_FILES["imaxe"]) && $_FILES["imaxe"]["error"] == 0) {
                $rutatemporal = $_FILES["imaxe"]["tmp_name"];
                $destino = "../img/" . $imaxe['name'];
                if (!move_uploaded_file($rutatemporal, $destino)) {
                    array_push($errores, "<p style = 'color: red'>Hubo un error al cargar un archivo.</p>");
                    return $errores;
                }
            } else {
                array_push($errores, "<p style = 'color: red'>Imaxe no válida.</p>");
                return $errores;
            }
            $nuevaRuta = new Ruta();
            $nuevaRuta->crear($nome, $dificultad, $estado_actual, $distancia, $temporada, $imaxe['name']);
            $dao = new DAO_class();
            if ($dao->añadirRuta($nuevaRuta, $idsConcellos)) {
                return true;
            } else {
                array_push($errores, '<p style="color:red">Error ao interntar engadir a nova ruta.</p>');
                return $errores;
            }
        } else {
            return $errores;
        }
    }

    public function validarFormularioModificarRuta($id, $nome, $dificultad, $estado_actual, $distancia, $temporada, $imaxe, $idsConcellos)
    {
        $nomeCorrecto = false;
        $dificultadCorrecto = false;
        $estado_actualCorrecto = false;
        $distanciaCorrecto = false;
        $imaxeCorrecto = false;
        $concellosCorrecto = false;

        $errores = [];

        if (empty($nome)) {
            array_push($errores, '<p style="color:red">O campo do nome non pode estar baleiro.</p>');
        } else if (strlen($nome) > 30) {
            array_push($errores, '<p style="color:red">O campo do nome non pode superar os 30 caracteres.</p>');
        } else {
            $nomeCorrecto = true;
        }

        if ($dificultad == '') {
            array_push($errores, '<p style="color:red">O apartado de dificultade non pode estar baleiro.</p>');
        } else {
            $dificultadCorrecto = true;
        }

        if ($estado_actual == '') {
            array_push($errores, '<p style="color:red">O apartado de estado actual non pode estar baleiro.</p>');
        } else {
            $estado_actualCorrecto = true;
        }

        if (empty($distancia)) {
            array_push($errores, '<p style="color:red">O apartado de distancia non pode estar baleiro.</p>');
        } else if (!is_numeric($distancia)) {
            array_push($errores, '<p style="color:red">O apartado de distancia ten que ter un valor numérico.</p>');
        } else if ($distancia > 100) {
            array_push($errores, '<p style="color:red">O apartado de distancia non pode superar os 100 km.</p>');
        } else {
            $distanciaCorrecto = true;
        }

        if (!isset($imaxe)) {
            array_push($errores, '<p style = "color:red">O campo da imaxe é obrigatorio.</p>');
        } else {
            $imaxeCorrecto = true;
        }

        if (empty($idsConcellos)) {
            array_push($errores, '<p style="color:red">O campo de concellos non pode estar baleiro.</p>');
        } else {
            $concellosCorrecto = true;
        }

        if ($nomeCorrecto == true && $dificultadCorrecto == true && $estado_actualCorrecto == true && $distanciaCorrecto == true && $imaxeCorrecto == true && $concellosCorrecto == true) {
            $dao = new DAO_class();
            $imagenBBDD = $dao->obtenerRuta($id);
            unlink('../img/' . $imagenBBDD->imaxe);
            if (isset($_FILES["imaxe"]) && $_FILES["imaxe"]["error"] == 0) {
                $rutatemporal = $_FILES["imaxe"]["tmp_name"];
                $destino = "../img/" . $imaxe['name'];
                if (!move_uploaded_file($rutatemporal, $destino)) {
                    array_push($errores, "<p style = 'color: red'>Hubo un error al cargar un archivo.</p>");
                    return $errores;
                }
            } else {
                array_push($errores, "<p style = 'color: red'>Imaxe no válida.</p>");
                return $errores;
            }
            $objRuta = new Ruta();
            $objRuta->crear($nome, $dificultad, $estado_actual, $distancia, $temporada, $imaxe['name']);
            if ($dao->modificarRuta($id, $objRuta, $idsConcellos)) {
                return true;
            } else {
                array_push($errores, '<p style="color:red">Error ao interntar modificar a ruta.</p>');
                return $errores;
            }
        } else {
            return $errores;
        }
    }

    public function eliminarRuta($id)
    {
        $dao = new DAO_class();
        $ruta = $dao->obtenerRuta($id);
        unlink('../vista/img/' . $ruta->imaxe);
        $dao->borrarRuta($id);
    }
}
?>