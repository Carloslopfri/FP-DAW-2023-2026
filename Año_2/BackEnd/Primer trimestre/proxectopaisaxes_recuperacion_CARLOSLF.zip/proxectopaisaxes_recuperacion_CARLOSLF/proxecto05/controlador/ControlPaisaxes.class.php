<?php
/*

    @Título: Proxecto Paisaxe e sustentabilidade - Subproxecto 05
    
    @Autor: Carlos López Frieiro

    @Data modificación: 06/02/2025

    @Versión 1.1

*/

require_once __DIR__ . '/../modelo/DAO.class.php';

class ControlPsx {
    // Creamos la función para mostrar los datos de la base de datos, usando la función creada en la clase DAO.
    public function mostrarPaisaxes()
    {
        $dao = new DAO_class();
        $paisaxes = $dao->obtenerPaisaxes();
        return $paisaxes;
    }

    public function mostrarPaisaxe($id)
    {
        $dao = new DAO_class();
        $paisaxe = $dao->obtenerPaisaxe($id);
        return $paisaxe;
    }

    public function validarFormularioAñadirPaisaxe($nome, $altitud, $clima, $descripcion, $imaxe, $ubicacion, $ruta_id)
    {
        $nomeCorrecto = false;
        $altitudCorrecto = false;
        $climaCorrecto = false;
        $descripcionCorrecto = false;
        $imaxeCorrecto = false;
        $ubicacionCorrecto = false;
        $ruta_idCorrecto = false;

        $errores = [];

        if (empty($nome)) {
            array_push($errores, '<p style="color:red">O campo do nome non pode estar baleiro.</p>');
        } else if (strlen($nome) > 30) {
            array_push($errores, '<p style="color:red">O campo do nome non pode superar os 30 caracteres.</p>');
        } else {
            $nomeCorrecto = true;
        }

        if (empty($altitud)) {
            array_push($errores, '<p style="color:red">O campo de altitude non pode estar baleiro.</p>');
        } else if (!is_numeric($altitud)) {
            array_push($errores, '<p style="color:red">O campo de altitude ten que ser numérico.</p>');
        } else {
            $altitudCorrecto = true;
        }

        if ($clima == '') {
            array_push($errores, '<p style="color:red">O campo do clima non pode estar Baleiro.</p>');
        } else {
            $climaCorrecto = true;
        }

        if (empty($descripcion)) {
            array_push($errores, '<p style="color:red">O apartado da descrición non pode estar baleiro.</p>');
        } else if (strlen($descripcion) > 10000) {
            array_push($errores, '<p style="color:red">O apartado da descrición non pode ter máis de 10000 caracteres.</p>');
        } else {
            $descripcionCorrecto = true;
        }

        if (!isset($imaxe)) {
            array_push($errores, '<p style = "color:red">O campo da imaxe é obrigatorio.</p>');
        } else {
            $imaxeCorrecto = true;
        }

        if (empty($ubicacion)) {
            array_push($errores, '<p style="color:red">O apartado da ubicación non pode estar baleiro.</p>');
        } else {
            $ubicacionCorrecto = true;
        }

        if ($ruta_id == '') {
            array_push($errores, '<p style="color:red">O apartado da etapa no pode estar baleiro.</p>');
        } else {
            $ruta_idCorrecto = true;
        }

        if ($nomeCorrecto == true && $altitudCorrecto == true && $climaCorrecto == true && $descripcionCorrecto == true && $imaxeCorrecto == true && $ubicacionCorrecto == true && $ruta_idCorrecto == true) {
            if (isset($_FILES["imaxe"]) && $_FILES["imaxe"]["error"] == 0) {
                $rutatemporal = $_FILES["imaxe"]["tmp_name"];
                $destino = "../img/" . $imaxe['name'];
                if (!move_uploaded_file($rutatemporal, $destino)) {
                    array_push($errores, "<p style = 'color: red'>Hubo un error al cargar un archivo.</p>");
                    return $errores;
                }
            } else {
                array_push($errores, "<p style = 'color: red'>Imaxe no válida.</p>");
                return $errores;
            }
            $nuevaPaisaxe = new Paisaxe();
            $nuevaPaisaxe->crear($nome, $altitud, $clima, $descripcion, $imaxe['name'], $ubicacion, $ruta_id);
            $dao = new DAO_class();
            if ($dao->añadirPaisaxe($nuevaPaisaxe)) {
                return true;
            } else {
                array_push($errores, '<p style="color:red">Error ao interntar engadir a nova paisaxe.</p>');
                return $errores;
            }
        } else {
            return $errores;
        }
    }

    public function eliminarPaisaxe($id)
    {
        $dao = new DAO_class();
        $paisaxe = $dao->obtenerPaisaxe($id);
        unlink('../vista/img/' . $paisaxe->imaxe);
        $dao->borrarPaisaxe($id);
    }

    public function validarFormularioModificarPaisaxe($id, $nome, $altitud, $clima, $descripcion, $imaxe, $ubicacion, $ruta_id)
    {
        $nomeCorrecto = false;
        $altitudCorrecto = false;
        $climaCorrecto = false;
        $descripcionCorrecto = false;
        $imaxeCorrecto = false;
        $ubicacionCorrecto = false;
        $ruta_idCorrecto = false;

        $errores = [];

        if (empty($nome)) {
            array_push($errores, '<p style="color:red">O campo do nome non pode estar baleiro.</p>');
        } else if (strlen($nome) > 30) {
            array_push($errores, '<p style="color:red">O campo do nome non pode superar os 30 caracteres.</p>');
        } else {
            $nomeCorrecto = true;
        }

        if (empty($altitud)) {
            array_push($errores, '<p style="color:red">O campo de altitude non pode estar baleiro.</p>');
        } else if (!is_numeric($altitud)) {
            array_push($errores, '<p style="color:red">O campo de altitude ten que ser numérico.</p>');
        } else {
            $altitudCorrecto = true;
        }

        if ($clima == '') {
            array_push($errores, '<p style="color:red">O campo do clima non pode estar Baleiro.</p>');
        } else {
            $climaCorrecto = true;
        }

        if (empty($descripcion)) {
            array_push($errores, '<p style="color:red">O apartado da descrición non pode estar baleiro.</p>');
        } else if (strlen($descripcion) > 10000) {
            array_push($errores, '<p style="color:red">O apartado da descrición non pode ter máis de 10000 caracteres.</p>');
        } else {
            $descripcionCorrecto = true;
        }

        if (!isset($imaxe)) {
            array_push($errores, '<p style = "color:red">O campo da imaxe é obrigatorio.</p>');
        } else {
            $imaxeCorrecto = true;
        }

        if (empty($ubicacion)) {
            array_push($errores, '<p style="color:red">O apartado da ubicación non pode estar baleiro.</p>');
        } else {
            $ubicacionCorrecto = true;
        }

        if ($ruta_id == '') {
            array_push($errores, '<p style="color:red">O apartado da etapa no pode estar baleiro.</p>');
        } else {
            $ruta_idCorrecto = true;
        }

        if ($nomeCorrecto == true && $altitudCorrecto == true && $climaCorrecto == true && $descripcionCorrecto == true && $imaxeCorrecto == true && $ubicacionCorrecto == true && $ruta_idCorrecto == true) {
            $dao = new DAO_class();
            $imagenBBDD = $dao->obtenerPaisaxe($id);
            unlink('../img/' . $imagenBBDD->imaxe);
            if (isset($_FILES["imaxe"]) && $_FILES["imaxe"]["error"] == 0) {
                $rutatemporal = $_FILES["imaxe"]["tmp_name"];
                $destino = "../img/" . $imaxe['name'];
                if (!move_uploaded_file($rutatemporal, $destino)) {
                    array_push($errores, "<p style = 'color: red'>Hubo un error al cargar un archivo.</p>");
                    return $errores;
                }
            } else {
                array_push($errores, "<p style = 'color: red'>Imaxe no válida.</p>");
                return $errores;
            }
            $objPaisaxe = new Paisaxe();
            $objPaisaxe->crear($nome, $altitud, $clima, $descripcion, $imaxe['name'], $ubicacion, $ruta_id);
            if ($dao->modificarPaisaxe($id, $objPaisaxe) === true) {
                return true;
            } else {
                array_push($errores, '<p style="color:red">Error ao interntar modificar a paisaxe.</p>');
                return $errores;
            }
        } else {
            return $errores;
        }
    }
}
?>