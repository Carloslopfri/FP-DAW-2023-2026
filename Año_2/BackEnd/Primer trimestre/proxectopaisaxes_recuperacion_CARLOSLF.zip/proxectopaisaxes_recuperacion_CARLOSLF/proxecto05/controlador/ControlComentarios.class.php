<?php
/*

    @Título: Proxecto Paisaxe e sustentabilidade - Subproxecto 05
    
    @Autor: Carlos López Frieiro

    @Data modificación: 06/02/2025

    @Versión 1.1

*/

require_once __DIR__ . '/../modelo/DAO.class.php';

class ControlCmt
{
    public function mostrarComentariosPaisaxe($id)
    {
        $dao = new DAO_class();
        $comentario = $dao->obtenerComentariosPaisaxe($id);
        return $comentario;
    }

    public function mostrarComentarios()
    {
        $dao = new DAO_class();
        $comentarios = $dao->obtenerComentarios();
        return $comentarios;
    }

    public function eliminarComentario($id)
    {
        $dao = new DAO_class();
        $dao->borrarComentario($id);
    }

    public function validarFormularioAñadirComentario($comentario, $id)
    {
        $comentarioCorrecto = false;

        if (empty($comentario)) {
            $error = '<p style="color:red">Non podes mandar un comentario baleiro.</p>';
        } else if (strlen($comentario) > 2000) {
            $error = '<p style="color:red">O comentario non pode superar os 2000 caracteres.</p>';
        } else {
            $comentarioCorrecto = true;
        }

        if ($comentarioCorrecto == true) {
            $data = date('Y-m-d');
            $puntuacion = 0;
            $likes = 0;
            $paisaxe_id = $id;
            $nuevoComentario = new Comentario();
            $nuevoComentario->crear($comentario, $data, $puntuacion, $likes, $paisaxe_id);
            $dao = new DAO_class();
            if ($dao->añadirComentario($nuevoComentario)) {
                return true;
            } else {
                $error = '<p style="color:red">Error ao engadir o comentario.</p>';
                return $error;
            }
        } else {
            return $error;
        }
    }
}
