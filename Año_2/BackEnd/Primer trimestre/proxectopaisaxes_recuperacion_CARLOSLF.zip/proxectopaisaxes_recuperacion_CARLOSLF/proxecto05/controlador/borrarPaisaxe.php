<?php
/*

    @Título: Proxecto Paisaxe e sustentabilidade - Subproxecto 05
    
    @Autor: Carlos López Frieiro

    @Data modificación: 06/02/2025

    @Versión 1.1

*/

include './ControlPaisaxes.class.php';
$id = $_GET['id'];
$control = new ControlPsx();
$control->eliminarPaisaxe($id);
header('Location: ../vista/codigo/fichaCRUDpaisaxes.php');
exit();
?>