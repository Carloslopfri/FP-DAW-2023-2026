<?php
/*

    @Título: Proxecto Paisaxe e sustentabilidade - Subproxecto 05
    
    @Autor: Carlos López Frieiro

    @Data modificación: 06/02/2025

    @Versión 1.1

*/

require_once __DIR__ . '/../modelo/DAO.class.php';

class ControlCll {
    public function mostrarConcellosRuta($id)
    {
        $dao = new DAO_class();
        $concellos = $dao->obtenerConcellosRuta($id);
        return $concellos;
    }

    public function mostrarRutasConcello($id)
    {
        $dao = new DAO_class();
        $rutas = $dao->obtenerRutasConcello($id);
        return $rutas;
    }

    public function mostraConcello($id)
    {
        $dao = new DAO_class();
        $concello = $dao->obtenerConcello($id);
        return $concello;
    }

    public function mostrarConcellos()
    {
        $dao = new DAO_class();
        $concellos = $dao->obtenerConcellos();
        return $concellos;
    }

    public function validarFormularioAñadirConcello($nome, $provincia, $imaxe, $poboacion, $superficie, $ruta_id)
    {
        $nomeCorrecto = false;
        $provinciaCorrecto = false;
        $imaxeCorrecto = false;
        $poboacionCorrecto = false;
        $superficieCorrecto = false;
        $ruta_idCorrecto = false;

        $errores = [];

        if (empty($nome)) {
            array_push($errores, '<p style="color:red">O campo do nome non pode estar baleiro.</p>');
        } else if (strlen($nome) > 30) {
            array_push($errores, '<p style="color:red">O campo do nome non pode superar os 30 caracteres.</p>');
        } else {
            $nomeCorrecto = true;
        }

        if (empty($provincia)) {
            array_push($errores, '<p style="color:red">O campo da provincia non pode estar baleiro.</p>');
        } else if (strlen($provincia) > 30) {
            array_push($errores, '<p style="color:red">O campo da provincia non pode superar os 30 caracteres.</p>');
        } else {
            $provinciaCorrecto = true;
        }

        if (!isset($imaxe)) {
            array_push($errores, '<p style = "color:red">O campo da imaxe é obrigatorio.</p>');
        } else {
            $imaxeCorrecto = true;
        }

        if (empty($poboacion)) {
            array_push($errores, '<p style="color:red">O campo da poboación non pode estar baleiro.</p>');
        } else if (!is_numeric($poboacion)) {
            array_push($errores, '<p style="color:red">O campo da poboación ten que ser numérico.</p>');
        } else {
            $poboacionCorrecto = true;
        }

        if (empty($superficie)) {
            array_push($errores, '<p style="color:red">O campo da superficie non pode estar baleiro.</p>');
        } else if (!is_numeric($superficie)) {
            array_push($errores, '<p style="color:red">O campo da superficie ten que ser numérico.</p>');
        } else {
            $superficieCorrecto = true;
        }

        if ($ruta_id == '') {
            array_push($errores, '<p style="color:red">O campo da etapa non pode estar baleiro.</p>');
        } else {
            $ruta_idCorrecto = true;
        }

        if ($nomeCorrecto == true && $provinciaCorrecto == true && $imaxeCorrecto == true && $poboacionCorrecto == true && $superficieCorrecto == true && $ruta_idCorrecto == true) {
            if (isset($_FILES["imaxe"]) && $_FILES["imaxe"]["error"] == 0) {
                $rutatemporal = $_FILES["imaxe"]["tmp_name"];
                $destino = "../img/" . $imaxe['name'];
                if (!move_uploaded_file($rutatemporal, $destino)) {
                    array_push($errores, "<p style = 'color: red'>Hubo un error al cargar un archivo.</p>");
                    return $errores;
                }
            } else {
                array_push($errores, "<p style = 'color: red'>Imaxe no válida.</p>");
                return $errores;
            }
            $nuevoConcello = new Concello();
            $nuevoConcello->crear($nome, $provincia, $imaxe['name'], $poboacion, $superficie);
            $dao = new DAO_class();
            if ($dao->añadirConcello($nuevoConcello, $ruta_id)) {
                return true;
            } else {
                array_push($errores, '<p style="color:red">Error ao interntar engadir o novo concello.</p>');
                return $errores;
            }
        } else {
            return $errores;
        }
    }

    public function validarFormularioModificarConcello($id, $nome, $provincia, $imaxe, $poboacion, $superficie, $ruta_id)
    {
        $nomeCorrecto = false;
        $provinciaCorrecto = false;
        $imaxeCorrecto = false;
        $poboacionCorrecto = false;
        $superficieCorrecto = false;
        $ruta_idCorrecto = false;

        $errores = [];

        if (empty($nome)) {
            array_push($errores, '<p style="color:red">O campo do nome non pode estar baleiro.</p>');
        } else if (strlen($nome) > 30) {
            array_push($errores, '<p style="color:red">O campo do nome non pode superar os 30 caracteres.</p>');
        } else {
            $nomeCorrecto = true;
        }

        if (empty($provincia)) {
            array_push($errores, '<p style="color:red">O campo da provincia non pode estar baleiro.</p>');
        } else if (strlen($provincia) > 30) {
            array_push($errores, '<p style="color:red">O campo da provincia non pode superar os 30 caracteres.</p>');
        } else {
            $provinciaCorrecto = true;
        }

        if (!isset($imaxe)) {
            array_push($errores, '<p style = "color:red">O campo da imaxe é obrigatorio.</p>');
        } else {
            $imaxeCorrecto = true;
        }

        if (empty($poboacion)) {
            array_push($errores, '<p style="color:red">O campo da poboación non pode estar baleiro.</p>');
        } else if (!is_numeric($poboacion)) {
            array_push($errores, '<p style="color:red">O campo da poboación ten que ser numérico.</p>');
        } else {
            $poboacionCorrecto = true;
        }

        if (empty($superficie)) {
            array_push($errores, '<p style="color:red">O campo da superficie non pode estar baleiro.</p>');
        } else if (!is_numeric($superficie)) {
            array_push($errores, '<p style="color:red">O campo da superficie ten que ser numérico.</p>');
        } else {
            $superficieCorrecto = true;
        }

        if (empty($ruta_id)) {
            array_push($errores, '<p style="color:red">O campo da etapa non pode estar baleiro.</p>');
        } else {
            $ruta_idCorrecto = true;
        }

        if ($nomeCorrecto == true && $provinciaCorrecto == true && $imaxeCorrecto == true && $poboacionCorrecto == true && $superficieCorrecto == true && $ruta_idCorrecto == true) {
            $dao = new DAO_class();
            $imagenBBDD = $dao->obtenerConcello($id);
            unlink('../img/' . $imagenBBDD->imaxe);
            if (isset($_FILES["imaxe"]) && $_FILES["imaxe"]["error"] == 0) {
                $rutatemporal = $_FILES["imaxe"]["tmp_name"];
                $destino = "../img/" . $imaxe['name'];
                if (!move_uploaded_file($rutatemporal, $destino)) {
                    array_push($errores, "<p style = 'color: red'>Hubo un error al cargar un archivo.</p>");
                    return $errores;
                }
            } else {
                array_push($errores, "<p style = 'color: red'>Imaxe no válida.</p>");
                return $errores;
            }
            $objConcello = new Concello();
            $objConcello->crear($nome, $provincia, $imaxe['name'], $poboacion, $superficie);
            
            if ($dao->modificarConcello($id, $objConcello, $ruta_id)) {
                return true;
            } else {
                array_push($errores, '<p style="color:red">Error ao interntar modificar o concello.</p>');
                return $errores;
            }
        } else {
            return $errores;
        }
    }

    public function eliminarConcello($id)
    {
        $dao = new DAO_class();
        $concello = $dao->obtenerConcello($id);
        unlink('../vista/img/' . $concello->imaxe);
        $dao->borrarConcello($id);
    }
}
?>