<?php
/*

    @Título: Proxecto Paisaxe e sustentabilidade - Subproxecto 05
    
    @Autor: Carlos López Frieiro

    @Data modificación: 06/02/2025

    @Versión 1.1

*/

class Ruta {
    public string $nome;
    public string $dificultad;
    public string $estado_actual;
    public float $distancia;
    public string $temporada_recomendada;
    public string $imaxe;

    public function crear($nome, $dificultad, $estado_actual, $distancia, $temporada_recomendadad, $imaxe) {
        $this->nome = $nome;
        $this->dificultad = $dificultad;
        $this->estado_actual = $estado_actual;
        $this->distancia = $distancia;
        $this->temporada_recomendada = $temporada_recomendadad;
        $this->imaxe = $imaxe;
    }
}
?>