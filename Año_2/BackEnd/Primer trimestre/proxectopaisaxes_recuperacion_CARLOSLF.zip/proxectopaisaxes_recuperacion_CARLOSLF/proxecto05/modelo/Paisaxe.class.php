<?php
/*

    @Título: Proxecto Paisaxe e sustentabilidade - Subproxecto 05
    
    @Autor: Carlos López Frieiro

    @Data modificación: 06/02/2025

    @Versión 1.1

*/

class Paisaxe
{
    public  string $nome;
    public string $altitud;
    public string $clima;
    public string $descripcion;
    public string $imaxe;
    public string $ubicacion;
    public int $ruta_id;

    public function crear($nome, $altitud, $clima, $descripcion, $imaxe, $ubicacion, $ruta_id)
    {
        $this->nome = $nome;
        $this->altitud = $altitud;
        $this->clima = $clima;
        $this->descripcion = $descripcion;
        $this->imaxe = $imaxe;
        $this->ubicacion = $ubicacion;
        $this->ruta_id = $ruta_id;
    }
}
