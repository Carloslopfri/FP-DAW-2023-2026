<?php
/*

    @Título: Proxecto Paisaxe e sustentabilidade - Subproxecto 05
    
    @Autor: Carlos López Frieiro

    @Data modificación: 06/02/2025

    @Versión 1.1

*/

class Comentario {
    public string $contido;
    public string $data;
    public int $puntuacion;
    public int $likes;
    public int $paisaxe_id;

    public function crear($contido, $data, $puntuacion, $likes, $paisaxe_id) {
        $this->contido = $contido;
        $this->data = $data;
        $this->puntuacion = $puntuacion;
        $this->likes = $likes;
        $this->paisaxe_id = $paisaxe_id;
    }
}
?>