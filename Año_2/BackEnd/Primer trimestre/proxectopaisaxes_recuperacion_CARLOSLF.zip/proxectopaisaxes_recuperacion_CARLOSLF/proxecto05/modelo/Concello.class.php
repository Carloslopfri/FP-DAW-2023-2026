<?php
/*

    @Título: Proxecto Paisaxe e sustentabilidade - Subproxecto 05
    
    @Autor: Carlos López Frieiro

    @Data modificación: 06/02/2025

    @Versión 1.1

*/

class Concello
{
    public string $nome;
    public string $provincia;
    public string $imaxe;
    public int $poboacion;
    public float $superficie;

    public function crear($nome, $provincia, $imaxe, $poboacion, $superficie)
    {
        $this->nome = $nome;
        $this->provincia = $provincia;
        $this->imaxe = $imaxe;
        $this->poboacion = $poboacion;
        $this->superficie = $superficie;
    }
}
