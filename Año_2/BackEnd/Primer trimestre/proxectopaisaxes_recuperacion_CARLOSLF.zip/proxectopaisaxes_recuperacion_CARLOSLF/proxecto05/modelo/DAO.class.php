<?php
/*

    @Título: Proxecto Paisaxe e sustentabilidade - Subproxecto 05
    
    @Autor: Carlos López Frieiro

    @Data modificación: 06/02/2025

    @Versión 1.1

*/

require_once __DIR__ . '/Paisaxe.class.php';
require_once __DIR__ . '/Ruta.class.php';
require_once __DIR__ . '/Comentario.class.php';
require_once __DIR__ . '/Concello.class.php';

class DAO_class
{
    public $conexion;

    public function __construct()
    {
        try {
            $dsn = "mysql:host=localhost;dbname=proxectopaisaxes;charset=utf8";
            $usuario = 'phpmyadmin';
            $contraseña = 'xubu';
            $this->conexion = new PDO($dsn, $usuario, $contraseña);
            $this->conexion->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
            $this->conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo "Error para conectar á base de datos: " . $e->getMessage();
        }
    }

    public function obtenerPaisaxes()
    {
        try {
            $sql = 'SELECT * FROM proxecto05_paisaxes';
            $stmt = $this->conexion->prepare($sql);
            $stmt->execute();
            $paisaxes = $stmt->fetchAll(PDO::FETCH_CLASS, 'Paisaxe');
            return $paisaxes;
        } catch (PDOException $e) {
            return "Error para obter os paisaxes: " . $e->getMessage();
        }
    }

    public function obtenerPaisaxe($id)
    {
        try {
            $sql = 'SELECT * FROM proxecto05_paisaxes WHERE id = :id';
            $stmt = $this->conexion->prepare($sql);
            $stmt->bindValue(':id', $id, PDO::FETCH_ASSOC);
            $stmt->execute();
            $paisaxe = $stmt->fetchObject('Paisaxe');
            return $paisaxe;
        } catch (PDOException $e) {
            return "Error para obter o paisaxe: " . $e->getMessage();
        }
    }

    public function obtenerRuta($id)
    {
        try {
            $sql = 'SELECT * FROM proxecto05_rutas WHERE id = :id';
            $stmt = $this->conexion->prepare($sql);
            $stmt->bindValue(':id', $id, PDO::FETCH_ASSOC);
            $stmt->execute();
            $ruta = $stmt->fetchObject('Ruta');
            return $ruta;
        } catch (PDOException $e) {
            return "Error para obter a ruta: " . $e->getMessage();
        }
    }

    public function obtenerRutas()
    {
        try {
            $sql = 'SELECT * FROM proxecto05_rutas';
            $stmt = $this->conexion->prepare($sql);
            $stmt->execute();
            $rutas = $stmt->fetchAll(PDO::FETCH_CLASS, 'Ruta');
            return $rutas;
        } catch (PDOException $e) {
            return "Error para obter as rutas: " . $e->getMessage();
        }
    }

    public function obtenerComentariosPaisaxe($id)
    {
        try {
            $sql = 'SELECT * FROM proxecto05_comentarios WHERE paisaxe_id = :id';
            $stmt = $this->conexion->prepare($sql);
            $stmt->bindValue(':id', $id, PDO::FETCH_ASSOC);
            $stmt->execute();
            $comentario = $stmt->fetchAll(PDO::FETCH_CLASS, 'Comentario');
            return $comentario;
        } catch (PDOException $e) {
            return "Error para obter o comentario: " . $e->getMessage();
        }
    }

    public function obtenerConcellosRuta($id)
    {
        try {
            $sql = 'SELECT * FROM proxecto05_concello_ruta JOIN proxecto05_concellos ON concello_id = id WHERE ruta_id = :id';
            $stmt = $this->conexion->prepare($sql);
            $stmt->bindValue(':id', $id, PDO::FETCH_ASSOC);
            $stmt->execute();
            $concellos = $stmt->fetchAll(PDO::FETCH_CLASS, 'Concello');
            return $concellos;
        } catch (PDOException $e) {
            return "Error para obter os concellos: " . $e->getMessage();
        }
    }

    public function obtenerRutasConcello($id)
    {
        try {
            $sql = 'SELECT * FROM proxecto05_concello_ruta JOIN proxecto05_rutas ON ruta_id = id WHERE concello_id = :id';
            $stmt = $this->conexion->prepare($sql);
            $stmt->bindValue(':id', $id, PDO::FETCH_ASSOC);
            $stmt->execute();
            $rutas = $stmt->fetchAll(PDO::FETCH_CLASS, 'Concello');
            return $rutas;
        } catch (PDOException $e) {
            return "Error para obter os concellos: " . $e->getMessage();
        }
    }

    public function obtenerConcello($id)
    {
        try {
            $sql = 'SELECT * FROM proxecto05_concellos WHERE id = :id';
            $stmt = $this->conexion->prepare($sql);
            $stmt->bindValue(':id', $id, PDO::FETCH_ASSOC);
            $stmt->execute();
            $concello = $stmt->fetchObject('Concello');
            return $concello;
        } catch (PDOException $e) {
            return "Error para obter o concello: " . $e->getMessage();
        }
    }

    public function añadirComentario($objComentario)
    {
        try {
            $contido = $objComentario->contido;
            $data = $objComentario->data;
            $puntuacion = $objComentario->puntuacion;
            $likes = $objComentario->likes;
            $paisaxe_id = $objComentario->paisaxe_id;

            $sql = 'INSERT INTO proxecto05_comentarios (contido, data, puntuacion, likes, paisaxe_id) VALUES (:contido, :data, :puntuacion, :likes, :paisaxe_id)';
            $stm = $this->conexion->prepare($sql);
            $stm->bindParam(':contido', $contido, PDO::PARAM_STR);
            $stm->bindParam(':data', $data, PDO::PARAM_STR);
            $stm->bindParam(':puntuacion', $puntuacion, PDO::PARAM_STR);
            $stm->bindParam(':likes', $likes, PDO::PARAM_STR);
            $stm->bindParam(':paisaxe_id', $paisaxe_id, PDO::PARAM_STR);
            if ($stm->execute()) {
                return true;
            } else {
                return false;
            }
        } catch (PDOException $e) {
            return "Error para engadir o novo comentario: " . $e->getMessage();
        }
    }

    public function añadirPaisaxe($objPaisaxe)
    {
        try {
            $nome = $objPaisaxe->nome;
            $altitud = $objPaisaxe->altitud;
            $clima = $objPaisaxe->clima;
            $descripcion = $objPaisaxe->descripcion;
            $imaxe = $objPaisaxe->imaxe;
            $ubicacion = $objPaisaxe->ubicacion;
            $ruta_id = $objPaisaxe->ruta_id;

            $sql = 'INSERT INTO proxecto05_paisaxes (nome, altitud, clima, descripcion, imaxe, ubicacion, ruta_id) VALUES (:nome, :altitud, :clima, :descripcion, :imaxe, :ubicacion, :ruta_id)';
            $stm = $this->conexion->prepare($sql);
            $stm->bindParam(':nome', $nome, PDO::PARAM_STR);
            $stm->bindParam(':altitud', $altitud, PDO::PARAM_STR);
            $stm->bindParam(':clima', $clima, PDO::PARAM_STR);
            $stm->bindParam(':descripcion', $descripcion, PDO::PARAM_STR);
            $stm->bindParam(':imaxe', $imaxe, PDO::PARAM_STR);
            $stm->bindParam(':ubicacion', $ubicacion, PDO::PARAM_STR);
            $stm->bindParam(':ruta_id', $ruta_id, PDO::PARAM_STR);
            if ($stm->execute()) {
                return true;
            } else {
                return false;
            }
        } catch (PDOException $e) {
            return "Error para engadir o novo paisaxe: " . $e->getMessage();
        }
    }

    public function borrarPaisaxe($id)
    {
        try {
            $sql = 'DELETE FROM proxecto05_paisaxes WHERE id = :id';
            $stm = $this->conexion->prepare($sql);
            $stm->bindParam(':id', $id, PDO::PARAM_INT);
            $stm->execute();
        } catch (PDOException $e) {
            return "Error ao eliminar a paisaxe: " . $e->getMessage();
        }
    }

    public function modificarPaisaxe($id, $objPaisaxe)
    {
        try {
            $nome = $objPaisaxe->nome;
            $altitud = $objPaisaxe->altitud;
            $clima = $objPaisaxe->clima;
            $descripcion = $objPaisaxe->descripcion;
            $imaxe = $objPaisaxe->imaxe;
            $ubicacion = $objPaisaxe->ubicacion;
            $ruta_id = $objPaisaxe->ruta_id;

            $sql = 'UPDATE proxecto05_paisaxes SET nome = :nome, altitud = :altitud, clima = :clima, descripcion = :descripcion, imaxe = :imaxe, ubicacion = :ubicacion, ruta_id = :ruta_id WHERE id = :id';
            $stm = $this->conexion->prepare($sql);
            $stm->bindParam(':id', $id, PDO::PARAM_INT);
            $stm->bindParam(':nome', $nome, PDO::PARAM_STR);
            $stm->bindParam(':altitud', $altitud, PDO::PARAM_STR);
            $stm->bindParam(':clima', $clima, PDO::PARAM_STR);
            $stm->bindParam(':descripcion', $descripcion, PDO::PARAM_STR);
            $stm->bindParam(':imaxe', $imaxe, PDO::PARAM_STR);
            $stm->bindParam(':ubicacion', $ubicacion, PDO::PARAM_STR);
            $stm->bindParam(':ruta_id', $ruta_id, PDO::PARAM_INT);
            if ($stm->execute()) {
                return true;
            } else {
                return false;
            }
        } catch (PDOException $e) {
            return 'Error ao modificar a paisaxe: ' . $e->getMessage();
        }
    }

    public function obtenerComentarios()
    {
        try {
            $sql = 'SELECT * FROM proxecto05_comentarios';
            $stmt = $this->conexion->prepare($sql);
            $stmt->execute();
            $comentarios = $stmt->fetchAll(PDO::FETCH_CLASS, 'Comentario');
            return $comentarios;
        } catch (PDOException $e) {
            return "Error para obter os comentarios: " . $e->getMessage();
        }
    }

    public function borrarComentario($id)
    {
        try {
            $sql = 'DELETE FROM proxecto05_comentarios WHERE id = :id';
            $stm = $this->conexion->prepare($sql);
            $stm->bindParam(':id', $id, PDO::PARAM_INT);
            $stm->execute();
        } catch (PDOException $e) {
            return "Error ao eliminar o comentario: " . $e->getMessage();
        }
    }

    public function añadirRuta($objRuta, $idsConcellos)
    {
        try {
            $this->conexion->beginTransaction();

            $nome = $objRuta->nome;
            $dificultad = $objRuta->dificultad;
            $estado_actual = $objRuta->estado_actual;
            $distancia = $objRuta->distancia;
            $temporada_recomendada = $objRuta->temporada_recomendada;
            $imaxe = $objRuta->imaxe;

            $sql = 'INSERT INTO proxecto05_rutas (nome, dificultad, estado_actual, distancia, temporada_recomendada, imaxe) VALUES (:nome, :dificultad, :estado_actual, :distancia, :temporada_recomendada, :imaxe)';
            $stm = $this->conexion->prepare($sql);
            $stm->bindParam(':nome', $nome, PDO::PARAM_STR);
            $stm->bindParam(':dificultad', $dificultad, PDO::PARAM_STR);
            $stm->bindParam(':estado_actual', $estado_actual, PDO::PARAM_STR);
            $stm->bindParam(':distancia', $distancia, PDO::PARAM_STR);
            $stm->bindParam(':temporada_recomendada', $temporada_recomendada, PDO::PARAM_STR);
            $stm->bindParam(':imaxe', $imaxe, PDO::PARAM_STR);
            $stm->execute();

            $concello_id = $this->conexion->lastInsertId();
            $sqlPibote = 'INSERT INTO proxecto05_concello_ruta (concello_id, ruta_id) VALUES (:concello_id, :ruta_id)';
            $stmPibote = $this->conexion->prepare($sqlPibote);
            foreach ($idsConcellos as $idConcello) {
                $stmPibote->bindParam(':concello_id', $idConcello, PDO::PARAM_INT);
                $stmPibote->bindParam(':ruta_id', $concello_id, PDO::PARAM_INT);
                $stmPibote->execute();
            }

            if ($this->conexion->commit()) {
                return true;
            } else {
                return false;
            }
        } catch (PDOException $e) {
            $this->conexion->rollBack();
            return "Error para engadir a novo ruta: " . $e->getMessage();
        }
    }

    public function modificarRuta($id, $objRuta, $idsConcellos)
    {
        try {
            $this->conexion->beginTransaction();

            $nome = $objRuta->nome;
            $dificultad = $objRuta->dificultad;
            $estado_actual = $objRuta->estado_actual;
            $distancia = $objRuta->distancia;
            $temporada_recomendada = $objRuta->temporada_recomendada;
            $imaxe = $objRuta->imaxe;

            $sql = 'UPDATE proxecto05_rutas SET nome = :nome, dificultad = :dificultad, estado_actual = :estado_actual, distancia = :distancia, temporada_recomendada = :temporada_recomendada, imaxe = :imaxe WHERE id = :id';
            $stm = $this->conexion->prepare($sql);
            $stm->bindParam(':id', $id, PDO::PARAM_INT);
            $stm->bindParam(':nome', $nome, PDO::PARAM_STR);
            $stm->bindParam(':dificultad', $dificultad, PDO::PARAM_STR);
            $stm->bindParam(':estado_actual', $estado_actual, PDO::PARAM_STR);
            $stm->bindParam(':distancia', $distancia, PDO::PARAM_STR);
            $stm->bindParam(':temporada_recomendada', $temporada_recomendada, PDO::PARAM_STR);
            $stm->bindParam(':imaxe', $imaxe, PDO::PARAM_STR);
            $stm->execute();

            $sqlPiboteBorrar = 'DELETE FROM proxecto05_concello_ruta WHERE ruta_id = :id';
            $stmPiboteBorrar = $this->conexion->prepare($sqlPiboteBorrar);
            $stmPiboteBorrar->bindParam(':id', $id, PDO::PARAM_INT);
            $stmPiboteBorrar->execute();

            $sqlPiboteAnadir = 'INSERT INTO proxecto05_concello_ruta (concello_id, ruta_id) VALUES (:concello_id, :ruta_id)';
            $stmPiboteAnadir = $this->conexion->prepare($sqlPiboteAnadir);
            foreach ($idsConcellos as $idConcello) {
                $stmPiboteAnadir->bindParam(':concello_id', $idConcello, PDO::PARAM_INT);
                $stmPiboteAnadir->bindParam('ruta_id', $id, PDO::PARAM_INT);
                $stmPiboteAnadir->execute();
            }

            if ($this->conexion->commit()) {
                return true;
            } else {
                return false;
            }
        } catch (PDOException $e) {
            $this->conexion->rollBack();
            return 'Error ao modificar a ruta: ' . $e->getMessage();
        }
    }

    public function borrarRuta($id)
    {
        try {
            $this->conexion->beginTransaction();

            $sqlPibote = 'DELETE FROM proxecto05_concello_ruta WHERE ruta_id = :id';
            $stmPibote = $this->conexion->prepare($sqlPibote);
            $stmPibote->bindParam(':id', $id,  PDO::PARAM_INT);
            $stmPibote->execute();

            $sql = 'DELETE FROM proxecto05_rutas WHERE id = :id';
            $stm = $this->conexion->prepare($sql);
            $stm->bindParam(':id', $id, PDO::PARAM_INT);
            $stm->execute();

            $this->conexion->commit();
        } catch (PDOException $e) {
            $this->conexion->rollBack();
            return "Error ao eliminar a ruta: " . $e->getMessage();
        }
    }

    public function obtenerConcellos()
    {
        try {
            $sql = 'SELECT * FROM proxecto05_concellos';
            $stmt = $this->conexion->prepare($sql);
            $stmt->execute();
            $paisaxes = $stmt->fetchAll(PDO::FETCH_CLASS, 'Concello');
            return $paisaxes;
        } catch (PDOException $e) {
            return "Error para obter os concellos: " . $e->getMessage();
        }
    }

    public function añadirConcello($objConcello, $idsRutas) // Objeto y array.
    {
        try {
            // Iniciamos la transacción para poder ejercer más de una acción a la base de datos.
            $this->conexion->beginTransaction();

            $nome = $objConcello->nome;
            $provincia = $objConcello->provincia;
            $imaxe = $objConcello->imaxe;
            $poboacion = $objConcello->poboacion;
            $superficie = $objConcello->superficie;

            // Añadimos el concello de manera normal.
            $sql = 'INSERT INTO proxecto05_concellos (nome, provincia, imaxe, poboacion, superficie) VALUES (:nome, :provincia, :imaxe, :poboacion, :superficie)';
            $stm = $this->conexion->prepare($sql);
            $stm->bindParam(':nome', $nome, PDO::PARAM_STR);
            $stm->bindParam(':provincia', $provincia, PDO::PARAM_STR);
            $stm->bindParam(':imaxe', $imaxe, PDO::PARAM_STR);
            $stm->bindParam(':poboacion', $poboacion, PDO::PARAM_INT);
            $stm->bindParam(':superficie', $superficie, PDO::PARAM_STR);
            $stm->execute();

            // Añadimos el resto de datos de a la tabla pibote.
            $concello_id = $this->conexion->lastInsertId(); // Recoge el último id insertado.
            $sqlPibote = 'INSERT INTO proxecto05_concello_ruta (concello_id, ruta_id) VALUES (:concello_id, :ruta_id)';
            $stmPibote = $this->conexion->prepare($sqlPibote);
            foreach ($idsRutas as $idRuta) {
                $stmPibote->bindParam(':concello_id', $concello_id, PDO::PARAM_INT);
                $stmPibote->bindParam(':ruta_id', $idRuta, PDO::PARAM_INT);
                $stmPibote->execute();
            }

            if ($this->conexion->commit()) {
                return true;
            } else {
                return false;
            }
        } catch (PDOException $e) {
            $this->conexion->rollBack();
            return "Error para engadir a novo concello: " . $e->getMessage();
        }
    }

    public function modificarConcello($id, $objConcello, $idsRutas)
    {
        try {
            $this->conexion->beginTransaction();

            $nome = $objConcello->nome;
            $provincia = $objConcello->provincia;
            $imaxe = $objConcello->imaxe;
            $poboacion = $objConcello->poboacion;
            $superficie = $objConcello->superficie;

            // Actualizamos.
            $sql = 'UPDATE proxecto05_concellos SET nome = :nome, provincia = :provincia, imaxe = :imaxe, poboacion = :poboacion, superficie = :superficie WHERE id = :id';
            $stm = $this->conexion->prepare($sql);
            $stm->bindParam(':id', $id, PDO::PARAM_INT);
            $stm->bindParam(':nome', $nome, PDO::PARAM_STR);
            $stm->bindParam(':provincia', $provincia, PDO::PARAM_STR);
            $stm->bindParam(':imaxe', $imaxe, PDO::PARAM_STR);
            $stm->bindParam(':poboacion', $poboacion, PDO::PARAM_STR);
            $stm->bindParam(':superficie', $superficie, PDO::PARAM_STR);
            $stm->execute();

            // Borramos.
            $sqlPiboteBorrar = 'DELETE FROM proxecto05_concello_ruta WHERE concello_id = :id';
            $stmPiboteBorrar = $this->conexion->prepare($sqlPiboteBorrar);
            $stmPiboteBorrar->bindParam(':id', $id, PDO::PARAM_INT);
            $stmPiboteBorrar->execute();

            // Añadimo de nuevo.
            $sqlPiboteAnadir = 'INSERT INTO proxecto05_concello_ruta (concello_id, ruta_id) VALUES (:concello_id, :ruta_id)';
            $stmPiboteAnadir = $this->conexion->prepare($sqlPiboteAnadir);
            foreach ($idsRutas as $idRuta) {
                $stmPiboteAnadir->bindParam(':concello_id', $id, PDO::PARAM_INT);
                $stmPiboteAnadir->bindParam(':ruta_id', $idRuta, PDO::PARAM_INT);
                $stmPiboteAnadir->execute();
            }

            if ($this->conexion->commit()) {
                return true;
            } else {
                return false;
            }
        } catch (PDOException $e) {
            $this->conexion->rollBack();
            return 'Error ao modificar o concello: ' . $e->getMessage();
        }
    }

    public function borrarConcello($id)
    {
        // Siempre hay que borrar la tabla pibote antes que la tabla original.
        try {
            $this->conexion->beginTransaction();

            $sqlPibote = 'DELETE FROM proxecto05_concello_ruta WHERE concello_id = :concello_id';
            $stmPibote = $this->conexion->prepare($sqlPibote);
            $stmPibote->bindParam(':concello_id', $id, PDO::PARAM_INT);
            $stmPibote->execute();

            $sql = 'DELETE FROM proxecto05_concellos WHERE id = :id';
            $stm = $this->conexion->prepare($sql);
            $stm->bindParam(':id', $id, PDO::PARAM_INT);
            $stm->execute();

            $this->conexion->commit();
        } catch (PDOException $e) {
            $this->conexion->rollBack();
            return "Error ao eliminar o concello: " . $e->getMessage();
        }
    }
}
