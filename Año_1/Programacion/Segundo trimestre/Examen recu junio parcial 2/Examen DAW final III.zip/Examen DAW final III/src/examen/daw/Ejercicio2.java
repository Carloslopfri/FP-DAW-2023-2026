/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen.daw;



/**
 *
 * @author 
 */
public class Ejercicio2 {


    public static void ejecutar() {       


    }
    
}